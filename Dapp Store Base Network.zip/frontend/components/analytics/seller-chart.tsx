"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface SellerStats {
  seller: string
  listings: number
  sales: number
  volume: bigint
  commission: bigint
  avgPrice: bigint
}

interface SellerChartProps {
  data: SellerStats[]
  title: string
}

export function SellerChart({ data, title }: SellerChartProps) {
  const maxVolume = data.length > 0 ? Math.max(...data.map((d) => Number(d.volume))) : 0

  return (
    <Card>
      <CardHeader>
        <CardTitle>{title}</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {data.slice(0, 10).map((seller, index) => {
            const volumePercent = maxVolume > 0 ? (Number(seller.volume) / maxVolume) * 100 : 0

            return (
              <div key={seller.seller} className="space-y-1">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-mono text-xs">
                    {seller.seller.slice(0, 6)}...{seller.seller.slice(-4)}
                  </span>
                  <span className="font-medium">{(Number(seller.volume) / 1e18).toFixed(4)} ETH</span>
                </div>
                <div className="w-full bg-muted rounded-full h-2">
                  <div
                    className="bg-primary h-2 rounded-full transition-all duration-300"
                    style={{ width: `${volumePercent}%` }}
                  />
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}
