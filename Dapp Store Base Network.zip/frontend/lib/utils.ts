import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

export function formatAddress(address: string): string {
  return `${address.slice(0, 6)}...${address.slice(-4)}`
}

export function formatPrice(price: string, decimals = 18): string {
  const value = Number.parseFloat(price) / Math.pow(10, decimals)
  return value.toFixed(4)
}

export function parsePrice(price: string, decimals = 18): bigint {
  const value = Number.parseFloat(price) * Math.pow(10, decimals)
  return BigInt(Math.floor(value))
}
