"use client"

import { useState } from "react"
import { useContractWrite, useAccount, useWaitForTransaction } from "wagmi"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { FACTORY_ABI } from "@/lib/contracts"
import { Plus, Palette } from "lucide-react"

const FACTORY_ADDRESS = process.env.NEXT_PUBLIC_FACTORY_ADDRESS as `0x${string}`

export default function Create() {
  const { address } = useAccount()
  const [collectionType, setCollectionType] = useState<"721" | "1155">("721")
  const [formData, setFormData] = useState({
    name: "",
    symbol: "",
    baseURI: "",
    royaltyBps: "500", // 5% default
  })
  const [createdCollection, setCreatedCollection] = useState<string | null>(null)

  // Create ERC-721 collection
  const {
    data: create721Data,
    write: createDapp721,
    isLoading: isCreating721,
  } = useContractWrite({
    address: FACTORY_ADDRESS,
    abi: FACTORY_ABI,
    functionName: "createDapp721",
    onSuccess: (data) => {
      console.log("ERC-721 collection creation initiated:", data.hash)
    },
  })

  // Create ERC-1155 collection
  const {
    data: create1155Data,
    write: createDapp1155,
    isLoading: isCreating1155,
  } = useContractWrite({
    address: FACTORY_ADDRESS,
    abi: FACTORY_ABI,
    functionName: "createDapp1155",
    onSuccess: (data) => {
      console.log("ERC-1155 collection creation initiated:", data.hash)
    },
  })

  // Wait for transaction confirmation
  const { isLoading: isWaiting } = useWaitForTransaction({
    hash: create721Data?.hash || create1155Data?.hash,
    onSuccess: (receipt) => {
      // Extract collection address from logs
      const log = receipt.logs.find((log) => log.topics[0] === "0x..." /* CollectionCreated event signature */)
      if (log) {
        // Parse the collection address from the log
        setCreatedCollection(log.address)
      }
    },
  })

  const handleCreate = () => {
    if (!formData.baseURI || !formData.royaltyBps) return

    const royaltyBps = Number.parseInt(formData.royaltyBps)

    if (collectionType === "721") {
      if (!formData.name || !formData.symbol) return
      createDapp721({
        args: [formData.name, formData.symbol, formData.baseURI, royaltyBps],
      })
    } else {
      createDapp1155({
        args: [formData.baseURI, royaltyBps],
      })
    }
  }

  const isLoading = isCreating721 || isCreating1155 || isWaiting

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <Palette className="h-8 w-8" />
          Create NFT Collection
        </h1>
        <p className="text-muted-foreground">Deploy your own ERC-721 or ERC-1155 collection for your dapp</p>
      </div>

      {!address && (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">Connect your wallet to create NFT collections</p>
          </CardContent>
        </Card>
      )}

      {address && !createdCollection && (
        <div className="space-y-6">
          {/* Collection Type Selection */}
          <Card>
            <CardHeader>
              <CardTitle>Collection Type</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-2 gap-4">
                <Button
                  variant={collectionType === "721" ? "default" : "outline"}
                  onClick={() => setCollectionType("721")}
                  className="h-20 flex-col"
                >
                  <span className="font-semibold">ERC-721</span>
                  <span className="text-xs text-muted-foreground">Unique NFTs</span>
                </Button>
                <Button
                  variant={collectionType === "1155" ? "default" : "outline"}
                  onClick={() => setCollectionType("1155")}
                  className="h-20 flex-col"
                >
                  <span className="font-semibold">ERC-1155</span>
                  <span className="text-xs text-muted-foreground">Multi-edition NFTs</span>
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Collection Details Form */}
          <Card>
            <CardHeader>
              <CardTitle>Collection Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {collectionType === "721" && (
                <>
                  <div>
                    <label className="text-sm font-medium">Collection Name</label>
                    <Input
                      placeholder="My Dapp Collection"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                    />
                  </div>

                  <div>
                    <label className="text-sm font-medium">Symbol</label>
                    <Input
                      placeholder="MDC"
                      value={formData.symbol}
                      onChange={(e) => setFormData({ ...formData, symbol: e.target.value })}
                    />
                  </div>
                </>
              )}

              <div>
                <label className="text-sm font-medium">Base URI</label>
                <Input
                  placeholder="https://api.mydapp.com/metadata/"
                  value={formData.baseURI}
                  onChange={(e) => setFormData({ ...formData, baseURI: e.target.value })}
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Base URI for token metadata (IPFS or your API endpoint)
                </p>
              </div>

              <div>
                <label className="text-sm font-medium">Royalty Percentage</label>
                <Input
                  type="number"
                  placeholder="5"
                  min="0"
                  max="100"
                  value={Number.parseInt(formData.royaltyBps) / 100}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      royaltyBps: (Number.parseFloat(e.target.value) * 100).toString(),
                    })
                  }
                />
                <p className="text-xs text-muted-foreground mt-1">
                  Percentage of secondary sales you'll receive as royalties
                </p>
              </div>
            </CardContent>
          </Card>

          {/* Create Button */}
          <Card>
            <CardContent className="pt-6">
              <Button
                onClick={handleCreate}
                disabled={
                  isLoading ||
                  !formData.baseURI ||
                  !formData.royaltyBps ||
                  (collectionType === "721" && (!formData.name || !formData.symbol))
                }
                className="w-full"
                size="lg"
              >
                {isLoading ? (
                  "Creating Collection..."
                ) : (
                  <>
                    <Plus className="h-4 w-4 mr-2" />
                    Create {collectionType === "721" ? "ERC-721" : "ERC-1155"} Collection
                  </>
                )}
              </Button>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Success State */}
      {createdCollection && (
        <Card className="border-green-200 bg-green-50">
          <CardHeader>
            <CardTitle className="text-green-800">Collection Created Successfully!</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <p className="text-sm font-medium text-green-800">Collection Address:</p>
              <p className="font-mono text-sm bg-white p-2 rounded border">{createdCollection}</p>
            </div>

            <div className="flex space-x-2">
              <Button asChild className="flex-1">
                <a href={`/mint?collection=${createdCollection}`}>Mint NFTs</a>
              </Button>
              <Button
                variant="outline"
                onClick={() => {
                  setCreatedCollection(null)
                  setFormData({ name: "", symbol: "", baseURI: "", royaltyBps: "500" })
                }}
              >
                Create Another
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
