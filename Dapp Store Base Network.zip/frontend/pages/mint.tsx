"use client"

import { useState, useEffect } from "react"
import { useRouter } from "next/router"
import { useContractWrite, useAccount, useContractRead } from "wagmi"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { DAPP721_ABI, DAPP1155_ABI, MARKETPLACE_ABI, ERC20_ABI } from "@/lib/contracts"
import { formatAddress, parsePrice } from "@/lib/utils"
import { Coins, Zap } from "lucide-react"

const MARKETPLACE_ADDRESS = process.env.NEXT_PUBLIC_CONTRACT_ADDRESS as `0x${string}`
const USDC_ADDRESS = process.env.NEXT_PUBLIC_USDC_ADDRESS as `0x${string}`

export default function Mint() {
  const router = useRouter()
  const { address } = useAccount()
  const { collection } = router.query

  const [nftType, setNftType] = useState<"721" | "1155">("721")
  const [mintData, setMintData] = useState({
    recipient: "",
    tokenURI: "",
    amount: "1",
  })
  const [listingData, setListingData] = useState({
    payToken: "0x0000000000000000000000000000000000000000",
    price: "",
    autoList: false,
  })
  const [mintedTokenId, setMintedTokenId] = useState<string | null>(null)

  useEffect(() => {
    if (address) {
      setMintData({ ...mintData, recipient: address })
    }
  }, [address])

  // Get listing fee for auto-list feature
  const { data: listingFee } = useContractRead({
    address: MARKETPLACE_ADDRESS,
    abi: MARKETPLACE_ABI,
    functionName: "getListingFee",
  })

  // Mint ERC-721
  const { write: mint721, isLoading: isMinting721 } = useContractWrite({
    address: collection as `0x${string}`,
    abi: DAPP721_ABI,
    functionName: "mint",
    onSuccess: (data) => {
      console.log("ERC-721 minted:", data.hash)
    },
  })

  // Mint ERC-1155
  const { write: mint1155, isLoading: isMinting1155 } = useContractWrite({
    address: collection as `0x${string}`,
    abi: DAPP1155_ABI,
    functionName: "mint",
    onSuccess: (data) => {
      console.log("ERC-1155 minted:", data.hash)
    },
  })

  // Approve USDC for listing fee (if auto-listing)
  const { write: approveUSDC, isLoading: isApprovingUSDC } = useContractWrite({
    address: USDC_ADDRESS,
    abi: ERC20_ABI,
    functionName: "approve",
  })

  // Approve NFT for marketplace
  const { write: approveNFT, isLoading: isApprovingNFT } = useContractWrite({
    address: collection as `0x${string}`,
    abi: nftType === "721" ? DAPP721_ABI : DAPP1155_ABI,
    functionName: "setApprovalForAll",
  })

  // List on marketplace
  const { write: listNFT, isLoading: isListing } = useContractWrite({
    address: MARKETPLACE_ADDRESS,
    abi: MARKETPLACE_ABI,
    functionName: nftType === "721" ? "list721" : "list1155",
  })

  const handleMint = () => {
    if (!mintData.recipient || !mintData.tokenURI) return

    if (nftType === "721") {
      mint721({
        args: [mintData.recipient as `0x${string}`, mintData.tokenURI],
      })
    } else {
      const amount = BigInt(mintData.amount)
      mint1155({
        args: [mintData.recipient as `0x${string}`, amount, "0x"],
      })
    }
  }

  const handleApproveUSDC = () => {
    if (!listingFee) return
    approveUSDC({
      args: [MARKETPLACE_ADDRESS, listingFee as bigint],
    })
  }

  const handleApproveNFT = () => {
    approveNFT({
      args: [MARKETPLACE_ADDRESS, true],
    })
  }

  const handleList = () => {
    if (!mintedTokenId || !listingData.price) return

    const price = parsePrice(listingData.price)
    const tokenId = BigInt(mintedTokenId)
    const payToken = listingData.payToken as `0x${string}`
    const nftAddress = collection as `0x${string}`

    if (nftType === "721") {
      listNFT({
        args: [nftAddress, tokenId, payToken, price],
      })
    } else {
      const quantity = BigInt(mintData.amount)
      listNFT({
        args: [nftAddress, tokenId, payToken, price, quantity],
      })
    }
  }

  const isLoading = isMinting721 || isMinting1155 || isApprovingUSDC || isApprovingNFT || isListing

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="text-center space-y-2">
        <h1 className="text-3xl font-bold flex items-center justify-center gap-2">
          <Coins className="h-8 w-8" />
          Mint & List NFTs
        </h1>
        <p className="text-muted-foreground">Mint NFTs from your collection and optionally list them for sale</p>
        {collection && (
          <p className="text-sm font-mono bg-muted p-2 rounded">Collection: {formatAddress(collection as string)}</p>
        )}
      </div>

      {!address && (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">Connect your wallet to mint NFTs</p>
          </CardContent>
        </Card>
      )}

      {!collection && address && (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">
              No collection specified.{" "}
              <a href="/create" className="text-primary hover:underline">
                Create a collection first
              </a>
            </p>
          </CardContent>
        </Card>
      )}

      {address && collection && (
        <div className="space-y-6">
          {/* NFT Type Selection */}
          <Card>
            <CardHeader>
              <CardTitle>NFT Type</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-4">
                <Button variant={nftType === "721" ? "default" : "outline"} onClick={() => setNftType("721")}>
                  ERC-721
                </Button>
                <Button variant={nftType === "1155" ? "default" : "outline"} onClick={() => setNftType("1155")}>
                  ERC-1155
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Mint Form */}
          <Card>
            <CardHeader>
              <CardTitle>Mint Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">Recipient Address</label>
                <Input
                  placeholder="0x..."
                  value={mintData.recipient}
                  onChange={(e) => setMintData({ ...mintData, recipient: e.target.value })}
                />
              </div>

              <div>
                <label className="text-sm font-medium">Token URI</label>
                <Input
                  placeholder="https://api.mydapp.com/metadata/1.json"
                  value={mintData.tokenURI}
                  onChange={(e) => setMintData({ ...mintData, tokenURI: e.target.value })}
                />
                <p className="text-xs text-muted-foreground mt-1">Metadata URI for this specific token</p>
              </div>

              {nftType === "1155" && (
                <div>
                  <label className="text-sm font-medium">Amount</label>
                  <Input
                    type="number"
                    placeholder="1"
                    min="1"
                    value={mintData.amount}
                    onChange={(e) => setMintData({ ...mintData, amount: e.target.value })}
                  />
                </div>
              )}

              <Button
                onClick={handleMint}
                disabled={isLoading || !mintData.recipient || !mintData.tokenURI}
                className="w-full"
              >
                {isMinting721 || isMinting1155 ? "Minting..." : `Mint ${nftType === "721" ? "ERC-721" : "ERC-1155"}`}
              </Button>
            </CardContent>
          </Card>

          {/* Auto-List Option */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Zap className="h-5 w-5" />
                Quick List (Optional)
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center space-x-2">
                <input
                  type="checkbox"
                  id="autoList"
                  checked={listingData.autoList}
                  onChange={(e) => setListingData({ ...listingData, autoList: e.target.checked })}
                />
                <label htmlFor="autoList" className="text-sm font-medium">
                  List for sale immediately after minting
                </label>
              </div>

              {listingData.autoList && (
                <>
                  <div>
                    <label className="text-sm font-medium">Payment Token</label>
                    <select
                      className="w-full h-10 px-3 py-2 border border-input rounded-md bg-background"
                      value={listingData.payToken}
                      onChange={(e) => setListingData({ ...listingData, payToken: e.target.value })}
                    >
                      <option value="0x0000000000000000000000000000000000000000">ETH</option>
                      <option value={USDC_ADDRESS}>USDC</option>
                    </select>
                  </div>

                  <div>
                    <label className="text-sm font-medium">Price</label>
                    <Input
                      type="number"
                      step="0.0001"
                      placeholder="0.1"
                      value={listingData.price}
                      onChange={(e) => setListingData({ ...listingData, price: e.target.value })}
                    />
                  </div>

                  <div className="space-y-2">
                    <Button
                      onClick={handleApproveUSDC}
                      disabled={isLoading}
                      variant="outline"
                      size="sm"
                      className="w-full bg-transparent"
                    >
                      {isApprovingUSDC ? "Approving..." : "1. Approve USDC for listing fee"}
                    </Button>

                    <Button
                      onClick={handleApproveNFT}
                      disabled={isLoading}
                      variant="outline"
                      size="sm"
                      className="w-full bg-transparent"
                    >
                      {isApprovingNFT ? "Approving..." : "2. Approve NFT for marketplace"}
                    </Button>

                    <Button
                      onClick={handleList}
                      disabled={isLoading || !mintedTokenId || !listingData.price}
                      size="sm"
                      className="w-full"
                    >
                      {isListing ? "Listing..." : "3. List on marketplace"}
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {listingFee && (
            <Card>
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground text-center">
                  Listing fee: {(Number(listingFee) / 1e6).toFixed(2)} USDC
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  )
}
