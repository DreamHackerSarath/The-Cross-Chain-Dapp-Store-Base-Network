const { ethers } = require("hardhat")

const CHAIN_CONFIGS = {
  ethereum: {
    usdc: "0xA0b86a33E6441c8C06DD2b7c94b7E6E42342f8e1",
    name: "Ethereum Mainnet",
  },
  polygon: {
    usdc: "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174",
    name: "Polygon",
  },
  base: {
    usdc: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913",
    name: "Base",
  },
  arbitrum: {
    usdc: "0xaf88d065e77c8cC2239327C5EDb3A432268e5831",
    name: "Arbitrum One",
  },
  optimism: {
    usdc: "0x0b2C639c533813f4Aa9D7837CAf62653d097Ff85",
    name: "Optimism",
  },
  bsc: {
    usdc: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d",
    name: "BNB Smart Chain",
  },
}

async function deployToChain(chainName, config) {
  console.log(`\n=== Deploying to ${config.name} ===`)

  try {
    const [deployer] = await ethers.getSigners()
    const treasuryAddress = process.env.TREASURY_ADDRESS || deployer.address

    // Deploy AdvancedDappMarket
    const AdvancedDappMarket = await ethers.getContractFactory("AdvancedDappMarket")
    const market = await AdvancedDappMarket.deploy(config.usdc, treasuryAddress)
    await market.deployed()

    // Deploy DappFactory
    const DappFactory = await ethers.getContractFactory("DappFactory")
    const factory = await DappFactory.deploy()
    await factory.deployed()

    console.log(`✅ ${config.name} deployment successful:`)
    console.log(`   AdvancedDappMarket: ${market.address}`)
    console.log(`   DappFactory: ${factory.address}`)
    console.log(`   USDC: ${config.usdc}`)

    return {
      chain: chainName,
      market: market.address,
      factory: factory.address,
      usdc: config.usdc,
    }
  } catch (error) {
    console.log(`❌ ${config.name} deployment failed:`, error.message)
    return null
  }
}

async function main() {
  const targetChains = process.argv.slice(2)
  const chainsTodeploy =
    targetChains.length > 0 ? targetChains.filter((chain) => CHAIN_CONFIGS[chain]) : Object.keys(CHAIN_CONFIGS)

  console.log("Deploying to chains:", chainsTodeploy.join(", "))

  const results = []

  for (const chainName of chainsTodeploy) {
    const config = CHAIN_CONFIGS[chainName]
    const result = await deployToChain(chainName, config)
    if (result) {
      results.push(result)
    }
  }

  console.log("\n=== Multi-Chain Deployment Summary ===")
  results.forEach((result) => {
    console.log(`${result.chain}:`)
    console.log(`  Market: ${result.market}`)
    console.log(`  Factory: ${result.factory}`)
    console.log(`  USDC: ${result.usdc}`)
  })

  // Generate address mapping for frontend
  console.log("\n=== Address Mapping (for frontend) ===")
  const addressMap = {}
  results.forEach((result) => {
    addressMap[result.chain] = {
      market: result.market,
      factory: result.factory,
      usdc: result.usdc,
    }
  })
  console.log(JSON.stringify(addressMap, null, 2))
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error)
    process.exit(1)
  })
