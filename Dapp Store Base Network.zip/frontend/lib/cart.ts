export interface CartItem {
  listingId: number
  seller: string
  nft: string
  tokenId: number
  payToken: string
  price: string
  quantity: number
  listingType: number
  name?: string
  image?: string
}

export namespace CartManager {
  const STORAGE_KEY = "dapp-store-cart"

  export function getCart(): CartItem[] {
    if (typeof window === "undefined") return []

    try {
      const stored = localStorage.getItem(STORAGE_KEY)
      return stored ? JSON.parse(stored) : []
    } catch {
      return []
    }
  }

  export function addToCart(item: CartItem): void {
    const cart = getCart()
    const existingIndex = cart.findIndex((cartItem) => cartItem.listingId === item.listingId)

    if (existingIndex >= 0) {
      // Item already in cart, don't add duplicate
      return
    }

    cart.push(item)
    saveCart(cart)
  }

  export function removeFromCart(listingId: number): void {
    const cart = getCart().filter((item) => item.listingId !== listingId)
    saveCart(cart)
  }

  export function clearCart(): void {
    saveCart([])
  }

  export function isInCart(listingId: number): boolean {
    return getCart().some((item) => item.listingId === listingId)
  }

  export function getCartTotal(): { totalItems: number; totalValue: bigint; payTokens: Set<string> } {
    const cart = getCart()
    const payTokens = new Set<string>()
    let totalValue = 0n

    cart.forEach((item) => {
      payTokens.add(item.payToken)
      totalValue += BigInt(item.price)
    })

    return {
      totalItems: cart.length,
      totalValue,
      payTokens,
    }
  }

  export function groupByPayToken(): Record<string, CartItem[]> {
    const cart = getCart()
    const grouped: Record<string, CartItem[]> = {}

    cart.forEach((item) => {
      if (!grouped[item.payToken]) {
        grouped[item.payToken] = []
      }
      grouped[item.payToken].push(item)
    })

    return grouped
  }

  function saveCart(cart: CartItem[]): void {
    if (typeof window === "undefined") return

    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(cart))
      // Dispatch custom event for cart updates
      window.dispatchEvent(new CustomEvent("cartUpdated"))
    } catch (error) {
      console.error("Failed to save cart:", error)
    }
  }
}
