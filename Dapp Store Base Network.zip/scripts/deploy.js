const { ethers } = require("hardhat")
const hre = require("hardhat") // Declare hre variable

async function main() {
  const [deployer] = await ethers.getSigners()

  console.log("Deploying contracts with account:", deployer.address)
  console.log("Account balance:", (await deployer.getBalance()).toString())

  // Get deployment parameters from environment
  const usdcAddress = process.env.USDC_ADDRESS
  const treasuryAddress = process.env.TREASURY_ADDRESS || deployer.address

  if (!usdcAddress) {
    throw new Error("USDC_ADDRESS environment variable is required")
  }

  // Deploy AdvancedDappMarket
  const AdvancedDappMarket = await ethers.getContractFactory("AdvancedDappMarket")
  const market = await AdvancedDappMarket.deploy(usdcAddress, treasuryAddress)
  await market.deployed()

  console.log("AdvancedDappMarket deployed to:", market.address)

  // Deploy DappFactory
  const DappFactory = await ethers.getContractFactory("DappFactory")
  const factory = await DappFactory.deploy()
  await factory.deployed()

  console.log("DappFactory deployed to:", factory.address)

  // Output deployment info
  console.log("\n=== Deployment Summary ===")
  console.log("Network:", hre.network.name)
  console.log("AdvancedDappMarket:", market.address)
  console.log("DappFactory:", factory.address)
  console.log("USDC:", usdcAddress)
  console.log("Treasury:", treasuryAddress)

  console.log("\n=== Frontend Environment Variables ===")
  console.log(`NEXT_PUBLIC_CONTRACT_ADDRESS=${market.address}`)
  console.log(`NEXT_PUBLIC_FACTORY_ADDRESS=${factory.address}`)
  console.log(`NEXT_PUBLIC_USDC_ADDRESS=${usdcAddress}`)
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error)
    process.exit(1)
  })
