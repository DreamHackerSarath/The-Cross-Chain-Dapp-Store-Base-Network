# EVM Dapp Store Frontend

Next.js frontend for the cross-chain dapp marketplace.

## Features

- **Wallet Integration**: RainbowKit + wagmi for seamless Web3 connections
- **Market Browser**: View and purchase listed dapps
- **Listing Interface**: List ERC-721 and ERC-1155 NFTs
- **Analytics Dashboard**: Track marketplace activity
- **Responsive Design**: Mobile-first UI with Tailwind CSS

## Setup

1. **Install dependencies**:
   \`\`\`bash
   npm install
   \`\`\`

2. **Configure environment**:
   \`\`\`bash
   cp .env.example .env.local
   # Edit .env.local with your contract addresses
   \`\`\`

3. **Run development server**:
   \`\`\`bash
   npm run dev
   \`\`\`

## Environment Variables

- `NEXT_PUBLIC_CONTRACT_ADDRESS`: Deployed marketplace contract
- `NEXT_PUBLIC_FACTORY_ADDRESS`: Deployed factory contract  
- `NEXT_PUBLIC_USDC_ADDRESS`: USDC token address for the chain
- `NEXT_PUBLIC_SUBGRAPH_URL`: Optional subgraph endpoint

## Pages

- `/` - Landing page with features overview
- `/market` - Browse and purchase listings
- `/list` - Create new listings
- `/analytics` - View marketplace statistics

## Tech Stack

- **Framework**: Next.js 14
- **Web3**: wagmi + RainbowKit
- **Styling**: Tailwind CSS
- **UI Components**: Custom component library
- **State**: React Query for server state
