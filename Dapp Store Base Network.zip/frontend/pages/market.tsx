"use client"

import { useState, useEffect } from "react"
import { useContractReads, useContractWrite, useAccount } from "wagmi"
import { ListingCard } from "@/components/market/listing-card"
import { CartSidebar } from "@/components/market/cart-sidebar"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MARKETPLACE_ABI } from "@/lib/contracts"
import { CartManager } from "@/lib/cart"
import { getTokenPriceUSD } from "@/lib/pricing"
import { Search, Filter, ShoppingCart } from "lucide-react"

const CONTRACT_ADDRESS = process.env.NEXT_PUBLIC_CONTRACT_ADDRESS as `0x${string}`

interface Listing {
  id: number
  seller: string
  nft: string
  tokenId: number
  payToken: string
  price: string
  quantity: number
  listingType: number
  active: boolean
}

export default function Market() {
  const { address } = useAccount()
  const [listings, setListings] = useState<Listing[]>([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedListing, setSelectedListing] = useState<number | null>(null)
  const [isCartOpen, setIsCartOpen] = useState(false)
  const [cartItemCount, setCartItemCount] = useState(0)
  const [showUSDPrices, setShowUSDPrices] = useState(true)
  const [tokenPrices, setTokenPrices] = useState<Record<string, number>>({})

  // Get total number of listings
  const { data: nextListingId } = useContractReads({
    contracts: [
      {
        address: CONTRACT_ADDRESS,
        abi: MARKETPLACE_ABI,
        functionName: "nextListingId",
      },
    ],
  })

  // Get listings data
  const listingIds = Array.from({ length: Math.min(20, Number(nextListingId?.[0]?.result || 0)) }, (_, i) => i)

  const { data: listingsData } = useContractReads({
    contracts: listingIds.map((id) => ({
      address: CONTRACT_ADDRESS,
      abi: MARKETPLACE_ABI,
      functionName: "listings",
      args: [BigInt(id)],
    })),
  })

  // Buy item function
  const { write: buyItem, isLoading: isBuying } = useContractWrite({
    address: CONTRACT_ADDRESS,
    abi: MARKETPLACE_ABI,
    functionName: "buyItem",
  })

  // Report listing function
  const { write: reportListing } = useContractWrite({
    address: CONTRACT_ADDRESS,
    abi: MARKETPLACE_ABI,
    functionName: "reportListing",
  })

  useEffect(() => {
    if (listingsData) {
      const formattedListings: Listing[] = listingsData
        .map((result, index) => {
          if (result.status === "success" && result.result) {
            const [seller, nft, tokenId, payToken, price, quantity, listingType, active] = result.result as any[]
            return {
              id: index,
              seller,
              nft,
              tokenId: Number(tokenId),
              payToken,
              price: price.toString(),
              quantity: Number(quantity),
              listingType: Number(listingType),
              active,
            }
          }
          return null
        })
        .filter((listing): listing is Listing => listing !== null && listing.active)

      setListings(formattedListings)
    }
  }, [listingsData])

  useEffect(() => {
    const updateCartCount = () => {
      const { totalItems } = CartManager.getCartTotal()
      setCartItemCount(totalItems)
    }

    updateCartCount()
    window.addEventListener("cartUpdated", updateCartCount)

    return () => window.removeEventListener("cartUpdated", updateCartCount)
  }, [])

  useEffect(() => {
    const fetchPrices = async () => {
      const prices = {
        eth: await getTokenPriceUSD("eth"),
        usdc: await getTokenPriceUSD("usdc"),
      }
      setTokenPrices(prices)
    }

    if (showUSDPrices) {
      fetchPrices()
    }
  }, [showUSDPrices])

  const handleBuy = (id: number) => {
    const listing = listings.find((l) => l.id === id)
    if (!listing) return

    setSelectedListing(id)

    if (listing.payToken === "0x0000000000000000000000000000000000000000") {
      // Native token payment
      buyItem({
        args: [BigInt(id)],
        value: BigInt(listing.price),
      })
    } else {
      // ERC20 payment (requires prior approval)
      buyItem({
        args: [BigInt(id)],
      })
    }
  }

  const handleReport = (id: number) => {
    const reason = prompt("Please provide a reason for reporting this listing:")
    if (reason) {
      reportListing({
        args: [BigInt(id), reason],
      })
    }
  }

  const getTokenPrice = (payToken: string) => {
    return payToken === "0x0000000000000000000000000000000000000000" ? tokenPrices.eth : tokenPrices.usdc
  }

  const filteredListings = listings.filter(
    (listing) =>
      listing.nft.toLowerCase().includes(searchTerm.toLowerCase()) ||
      listing.seller.toLowerCase().includes(searchTerm.toLowerCase()),
  )

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 items-center justify-between">
        <h1 className="text-3xl font-bold">Dapp Marketplace</h1>

        <div className="flex items-center space-x-2">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-muted-foreground h-4 w-4" />
            <Input
              placeholder="Search by contract or seller..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 w-64"
            />
          </div>

          <Button variant="outline" size="sm" onClick={() => setShowUSDPrices(!showUSDPrices)}>
            {showUSDPrices ? "Hide USD" : "Show USD"}
          </Button>

          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>

          <Button variant="outline" onClick={() => setIsCartOpen(true)} className="relative">
            <ShoppingCart className="h-4 w-4" />
            {cartItemCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-primary text-primary-foreground text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {cartItemCount}
              </span>
            )}
          </Button>
        </div>
      </div>

      {!address && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">Connect your wallet to view and purchase listings</p>
        </div>
      )}

      {address && filteredListings.length === 0 && (
        <div className="text-center py-8">
          <p className="text-muted-foreground">No active listings found</p>
        </div>
      )}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filteredListings.map((listing) => (
          <ListingCard
            key={listing.id}
            listing={listing}
            onBuy={handleBuy}
            onReport={handleReport}
            isLoading={isBuying && selectedListing === listing.id}
            showUSDPrice={showUSDPrices}
            usdPrice={getTokenPrice(listing.payToken)}
          />
        ))}
      </div>

      <CartSidebar isOpen={isCartOpen} onClose={() => setIsCartOpen(false)} />
    </div>
  )
}
