"use client"

import { useNetwork, useSwitchNetwork } from "wagmi"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { supportedChains } from "@/lib/chains"
import { Badge } from "@/components/ui/badge"

export function ChainSelector() {
  const { chain } = useNetwork()
  const { switchNetwork } = useSwitchNetwork()

  const handleChainChange = (chainId: string) => {
    switchNetwork?.(Number(chainId))
  }

  return (
    <div className="flex items-center space-x-2">
      <span className="text-sm font-medium">Network:</span>
      <Select value={chain?.id?.toString()} onValueChange={handleChainChange}>
        <SelectTrigger className="w-40">
          <SelectValue placeholder="Select chain">
            {chain && (
              <div className="flex items-center space-x-2">
                <div className="w-2 h-2 rounded-full bg-green-500" />
                <span>{chain.name}</span>
              </div>
            )}
          </SelectValue>
        </SelectTrigger>
        <SelectContent>
          {supportedChains.map((supportedChain) => (
            <SelectItem key={supportedChain.id} value={supportedChain.id.toString()}>
              <div className="flex items-center justify-between w-full">
                <div className="flex items-center space-x-2">
                  <div
                    className={`w-2 h-2 rounded-full ${
                      chain?.id === supportedChain.id ? "bg-green-500" : "bg-gray-300"
                    }`}
                  />
                  <span>{supportedChain.name}</span>
                </div>
                {supportedChain.testnet && <Badge variant="secondary">Testnet</Badge>}
              </div>
            </SelectItem>
          ))}
        </SelectContent>
      </Select>
    </div>
  )
}
