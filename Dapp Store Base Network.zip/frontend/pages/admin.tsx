"use client"

import { useState, useEffect } from "react"
import { useAccount, useContractRead, useContractWrite, usePrepareContractWrite } from "wagmi"
import { formatEther } from "viem"
import { Button } from "../components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card"
import { Input } from "../components/ui/input"
import { Badge } from "../components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "../components/ui/tabs"
import { marketplaceABI, marketplaceAddress } from "../lib/contracts"

interface Report {
  listingId: number
  reporter: string
  reason: string
  timestamp: number
  resolved: boolean
}

interface EscrowItem {
  listingId: number
  buyer: string
  seller: string
  amount: string
  token: string
  timestamp: number
}

export default function AdminPage() {
  const { address } = useAccount()
  const [reports, setReports] = useState<Report[]>([])
  const [escrowItems, setEscrowItems] = useState<EscrowItem[]>([])
  const [selectedListing, setSelectedListing] = useState<number>(0)
  const [newPayToken, setNewPayToken] = useState("")

  // Check if user is admin
  const { data: isAdmin } = useContractRead({
    address: marketplaceAddress,
    abi: marketplaceABI,
    functionName: "hasRole",
    args: ["0x0000000000000000000000000000000000000000000000000000000000000000", address], // DEFAULT_ADMIN_ROLE
  })

  // Get marketplace balances
  const { data: totalVolume } = useContractRead({
    address: marketplaceAddress,
    abi: marketplaceABI,
    functionName: "totalVolume",
  })

  const { data: totalCommissions } = useContractRead({
    address: marketplaceAddress,
    abi: marketplaceABI,
    functionName: "totalCommissions",
  })

  // Freeze listing
  const { config: freezeConfig } = usePrepareContractWrite({
    address: marketplaceAddress,
    abi: marketplaceABI,
    functionName: "freezeListing",
    args: [selectedListing],
  })
  const { write: freezeListing } = useContractWrite(freezeConfig)

  // Unfreeze listing
  const { config: unfreezeConfig } = usePrepareContractWrite({
    address: marketplaceAddress,
    abi: marketplaceABI,
    functionName: "unfreezeListing",
    args: [selectedListing],
  })
  const { write: unfreezeListing } = useContractWrite(unfreezeConfig)

  // Release escrow
  const { config: releaseConfig } = usePrepareContractWrite({
    address: marketplaceAddress,
    abi: marketplaceABI,
    functionName: "releaseEscrow",
    args: [selectedListing],
  })
  const { write: releaseEscrow } = useContractWrite(releaseConfig)

  // Refund escrow
  const { config: refundConfig } = usePrepareContractWrite({
    address: marketplaceAddress,
    abi: marketplaceABI,
    functionName: "refundEscrow",
    args: [selectedListing],
  })
  const { write: refundEscrow } = useContractWrite(refundConfig)

  // Add pay token
  const { config: addTokenConfig } = usePrepareContractWrite({
    address: marketplaceAddress,
    abi: marketplaceABI,
    functionName: "addPayToken",
    args: [newPayToken],
  })
  const { write: addPayToken } = useContractWrite(addTokenConfig)

  // Load reports and escrow data
  useEffect(() => {
    // In a real app, you'd fetch this from events or a backend
    // For demo purposes, using mock data
    setReports([
      {
        listingId: 1,
        reporter: "0x1234...5678",
        reason: "Inappropriate content",
        timestamp: Date.now() - 86400000,
        resolved: false,
      },
      {
        listingId: 3,
        reporter: "0x9876...5432",
        reason: "Scam/Fraud",
        timestamp: Date.now() - 172800000,
        resolved: true,
      },
    ])

    setEscrowItems([
      {
        listingId: 2,
        buyer: "0xabcd...efgh",
        seller: "0x1111...2222",
        amount: "100",
        token: "USDC",
        timestamp: Date.now() - 3600000,
      },
    ])
  }, [])

  if (!isAdmin) {
    return (
      <div className="container mx-auto px-4 py-8">
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">Access denied. Admin privileges required.</p>
          </CardContent>
        </Card>
      </div>
    )
  }

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="mb-8">
        <h1 className="text-3xl font-bold">Admin Dashboard</h1>
        <p className="text-muted-foreground">Manage marketplace operations and moderation</p>
      </div>

      {/* Balance Overview */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
        <Card>
          <CardHeader>
            <CardTitle>Total Volume</CardTitle>
            <CardDescription>All-time marketplace volume</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{totalVolume ? formatEther(totalVolume as bigint) : "0"} ETH</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Total Commissions</CardTitle>
            <CardDescription>Platform earnings</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{totalCommissions ? formatEther(totalCommissions as bigint) : "0"} ETH</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Active Escrows</CardTitle>
            <CardDescription>Pending transactions</CardDescription>
          </CardHeader>
          <CardContent>
            <p className="text-2xl font-bold">{escrowItems.length}</p>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="reports" className="space-y-6">
        <TabsList>
          <TabsTrigger value="reports">Reports</TabsTrigger>
          <TabsTrigger value="escrow">Escrow Management</TabsTrigger>
          <TabsTrigger value="tokens">Payment Tokens</TabsTrigger>
          <TabsTrigger value="listings">Listing Management</TabsTrigger>
        </TabsList>

        <TabsContent value="reports">
          <Card>
            <CardHeader>
              <CardTitle>User Reports</CardTitle>
              <CardDescription>Review and resolve user-reported issues</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reports.map((report) => (
                  <div
                    key={`${report.listingId}-${report.timestamp}`}
                    className="flex items-center justify-between p-4 border rounded-lg"
                  >
                    <div>
                      <p className="font-medium">Listing #{report.listingId}</p>
                      <p className="text-sm text-muted-foreground">Reason: {report.reason}</p>
                      <p className="text-xs text-muted-foreground">
                        Reporter: {report.reporter} • {new Date(report.timestamp).toLocaleDateString()}
                      </p>
                    </div>
                    <div className="flex items-center gap-2">
                      <Badge variant={report.resolved ? "secondary" : "destructive"}>
                        {report.resolved ? "Resolved" : "Pending"}
                      </Badge>
                      {!report.resolved && (
                        <Button
                          size="sm"
                          onClick={() => {
                            setSelectedListing(report.listingId)
                            freezeListing?.()
                          }}
                        >
                          Freeze Listing
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="escrow">
          <Card>
            <CardHeader>
              <CardTitle>Escrow Management</CardTitle>
              <CardDescription>Manage disputed transactions and escrow releases</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {escrowItems.map((item) => (
                  <div key={item.listingId} className="flex items-center justify-between p-4 border rounded-lg">
                    <div>
                      <p className="font-medium">Listing #{item.listingId}</p>
                      <p className="text-sm text-muted-foreground">
                        Amount: {item.amount} {item.token}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        Buyer: {item.buyer} • Seller: {item.seller}
                      </p>
                      <p className="text-xs text-muted-foreground">{new Date(item.timestamp).toLocaleDateString()}</p>
                    </div>
                    <div className="flex gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => {
                          setSelectedListing(item.listingId)
                          refundEscrow?.()
                        }}
                      >
                        Refund Buyer
                      </Button>
                      <Button
                        size="sm"
                        onClick={() => {
                          setSelectedListing(item.listingId)
                          releaseEscrow?.()
                        }}
                      >
                        Release to Seller
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="tokens">
          <Card>
            <CardHeader>
              <CardTitle>Payment Token Management</CardTitle>
              <CardDescription>Add or remove accepted payment tokens</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2 mb-4">
                <Input
                  placeholder="Token contract address"
                  value={newPayToken}
                  onChange={(e) => setNewPayToken(e.target.value)}
                />
                <Button onClick={() => addPayToken?.()}>Add Token</Button>
              </div>
              <div className="text-sm text-muted-foreground">
                <p>Current accepted tokens:</p>
                <ul className="list-disc list-inside mt-2">
                  <li>USDC (Primary)</li>
                  <li>USDT</li>
                  <li>DAI</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="listings">
          <Card>
            <CardHeader>
              <CardTitle>Listing Management</CardTitle>
              <CardDescription>Freeze, unfreeze, or manage individual listings</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex gap-2 mb-4">
                <Input
                  type="number"
                  placeholder="Listing ID"
                  value={selectedListing}
                  onChange={(e) => setSelectedListing(Number(e.target.value))}
                />
                <Button variant="destructive" onClick={() => freezeListing?.()}>
                  Freeze
                </Button>
                <Button variant="outline" onClick={() => unfreezeListing?.()}>
                  Unfreeze
                </Button>
              </div>
              <p className="text-sm text-muted-foreground">
                Enter a listing ID to freeze or unfreeze it. Frozen listings cannot be purchased.
              </p>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
