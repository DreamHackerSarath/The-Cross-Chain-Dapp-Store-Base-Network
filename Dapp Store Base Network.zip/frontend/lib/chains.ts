import { mainnet, polygon, base, arbitrum, optimism, bsc } from "wagmi/chains"

export interface ChainConfig {
  id: number
  name: string
  nativeCurrency: {
    name: string
    symbol: string
    decimals: number
  }
  rpcUrls: {
    default: {
      http: string[]
    }
  }
  blockExplorers: {
    default: {
      name: string
      url: string
    }
  }
  contracts: {
    marketplace: `0x${string}`
    factory: `0x${string}`
    usdc: `0x${string}`
  }
  testnet?: boolean
}

export const supportedChains: ChainConfig[] = [
  {
    ...mainnet,
    contracts: {
      marketplace: "0x1234567890123456789012345678901234567890" as `0x${string}`,
      factory: "0x2345678901234567890123456789012345678901" as `0x${string}`,
      usdc: "0xA0b86a33E6441b8C4505B4afDcA7aBB2B6e1B071" as `0x${string}`, // USDC on Ethereum
    },
  },
  {
    ...polygon,
    contracts: {
      marketplace: "0x3456789012345678901234567890123456789012" as `0x${string}`,
      factory: "0x4567890123456789012345678901234567890123" as `0x${string}`,
      usdc: "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174" as `0x${string}`, // USDC on Polygon
    },
  },
  {
    ...base,
    contracts: {
      marketplace: "0x5678901234567890123456789012345678901234" as `0x${string}`,
      factory: "0x6789012345678901234567890123456789012345" as `0x${string}`,
      usdc: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913" as `0x${string}`, // USDC on Base
    },
  },
  {
    ...arbitrum,
    contracts: {
      marketplace: "0x7890123456789012345678901234567890123456" as `0x${string}`,
      factory: "0x8901234567890123456789012345678901234567" as `0x${string}`,
      usdc: "0xaf88d065e77c8cC2239327C5EDb3A432268e5831" as `0x${string}`, // USDC on Arbitrum
    },
  },
  {
    ...optimism,
    contracts: {
      marketplace: "0x9012345678901234567890123456789012345678" as `0x${string}`,
      factory: "0x0123456789012345678901234567890123456789" as `0x${string}`,
      usdc: "0x0b2C639c533813f4Aa9D7837CAf62653d097Ff85" as `0x${string}`, // USDC on Optimism
    },
  },
  {
    ...bsc,
    contracts: {
      marketplace: "0x1123456789012345678901234567890123456789" as `0x${string}`,
      factory: "0x2234567890123456789012345678901234567890" as `0x${string}`,
      usdc: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d" as `0x${string}`, // USDC on BSC
    },
  },
]

export function getChainConfig(chainId: number): ChainConfig | undefined {
  return supportedChains.find((chain) => chain.id === chainId)
}

export function getContractAddress(
  chainId: number,
  contract: keyof ChainConfig["contracts"],
): `0x${string}` | undefined {
  const config = getChainConfig(chainId)
  return config?.contracts[contract]
}
