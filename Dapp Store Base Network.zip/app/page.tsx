"use client"

import { SellerChart } from "../frontend/components/analytics/seller-chart"

export default function SyntheticV0PageForDeployment() {
  return <SellerChart />
}