import { getDefaultWallets } from "@rainbow-me/rainbowkit"
import { configureChains, createConfig } from "wagmi"
import { mainnet, polygon, base, arbitrum, optimism, bsc } from "wagmi/chains"
import { publicProvider } from "wagmi/providers/public"

const { chains, publicClient } = configureChains([mainnet, polygon, base, arbitrum, optimism, bsc], [publicProvider()])

const { connectors } = getDefaultWallets({
  appName: "EVM Dapp Store",
  projectId: "YOUR_PROJECT_ID", // Get from WalletConnect Cloud
  chains,
})

export const wagmiConfig = createConfig({
  autoConnect: false,
  connectors,
  publicClient,
})

export { chains }
