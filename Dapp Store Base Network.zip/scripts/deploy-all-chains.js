const hre = require("hardhat")
const fs = require("fs")
const path = require("path")

const chains = [
  { name: "ethereum", chainId: 1 },
  { name: "polygon", chainId: 137 },
  { name: "base", chainId: 8453 },
  { name: "arbitrum", chainId: 42161 },
  { name: "optimism", chainId: 10 },
  { name: "bsc", chainId: 56 },
]

const usdcAddresses = {
  1: "0xA0b86a33E6441b8C4505B4afDcA7aBB2B6e1B071", // Ethereum
  137: "0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174", // Polygon
  8453: "0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913", // Base
  42161: "0xaf88d065e77c8cC2239327C5EDb3A432268e5831", // Arbitrum
  10: "0x0b2C639c533813f4Aa9D7837CAf62653d097Ff85", // Optimism
  56: "0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d", // BSC
}

async function main() {
  const deployments = {}
  const treasuryAddress = process.env.TREASURY_ADDRESS || "0x1234567890123456789012345678901234567890"

  console.log("🚀 Starting multi-chain deployment...")
  console.log("Treasury Address:", treasuryAddress)

  for (const chain of chains) {
    try {
      console.log(`\n📡 Deploying to ${chain.name} (Chain ID: ${chain.chainId})...`)

      // Switch to the appropriate network
      await hre.changeNetwork(chain.name)

      const [deployer] = await hre.ethers.getSigners()
      console.log(`Deploying with account: ${deployer.address}`)

      const balance = await deployer.getBalance()
      console.log(`Account balance: ${hre.ethers.utils.formatEther(balance)} ETH`)

      const usdcAddress = usdcAddresses[chain.chainId]
      if (!usdcAddress) {
        console.log(`❌ No USDC address configured for ${chain.name}`)
        continue
      }

      // Deploy DappFactory
      console.log("Deploying DappFactory...")
      const DappFactory = await hre.ethers.getContractFactory("DappFactory")
      const factory = await DappFactory.deploy()
      await factory.deployed()
      console.log(`✅ DappFactory deployed to: ${factory.address}`)

      // Deploy AdvancedDappMarket
      console.log("Deploying AdvancedDappMarket...")
      const AdvancedDappMarket = await hre.ethers.getContractFactory("AdvancedDappMarket")
      const marketplace = await AdvancedDappMarket.deploy(usdcAddress, treasuryAddress)
      await marketplace.deployed()
      console.log(`✅ AdvancedDappMarket deployed to: ${marketplace.address}`)

      // Verify contracts on block explorer
      if (process.env.ETHERSCAN_API_KEY) {
        console.log("Verifying contracts...")
        try {
          await hre.run("verify:verify", {
            address: factory.address,
            constructorArguments: [],
          })
          console.log("✅ DappFactory verified")
        } catch (error) {
          console.log("❌ DappFactory verification failed:", error.message)
        }

        try {
          await hre.run("verify:verify", {
            address: marketplace.address,
            constructorArguments: [usdcAddress, treasuryAddress],
          })
          console.log("✅ AdvancedDappMarket verified")
        } catch (error) {
          console.log("❌ AdvancedDappMarket verification failed:", error.message)
        }
      }

      deployments[chain.chainId] = {
        chainName: chain.name,
        marketplace: marketplace.address,
        factory: factory.address,
        usdc: usdcAddress,
        treasury: treasuryAddress,
        deployer: deployer.address,
        blockNumber: await hre.ethers.provider.getBlockNumber(),
        timestamp: new Date().toISOString(),
      }

      console.log(`✅ ${chain.name} deployment completed!`)
    } catch (error) {
      console.log(`❌ ${chain.name} deployment failed:`, error.message)
      deployments[chain.chainId] = {
        chainName: chain.name,
        error: error.message,
        timestamp: new Date().toISOString(),
      }
    }
  }

  // Save deployment results
  const deploymentsPath = path.join(__dirname, "../deployments")
  if (!fs.existsSync(deploymentsPath)) {
    fs.mkdirSync(deploymentsPath, { recursive: true })
  }

  const deploymentFile = path.join(deploymentsPath, `multi-chain-${Date.now()}.json`)
  fs.writeFileSync(deploymentFile, JSON.stringify(deployments, null, 2))

  console.log(`\n📄 Deployment results saved to: ${deploymentFile}`)
  console.log("\n🎉 Multi-chain deployment completed!")

  // Generate frontend config
  generateFrontendConfig(deployments)
}

function generateFrontendConfig(deployments) {
  const configPath = path.join(__dirname, "../frontend/lib/deployed-contracts.ts")

  let configContent = `// Auto-generated deployment configuration
// Generated at: ${new Date().toISOString()}

export const deployedContracts = {
`

  for (const [chainId, deployment] of Object.entries(deployments)) {
    if (deployment.error) continue

    configContent += `  ${chainId}: {
    chainName: "${deployment.chainName}",
    marketplace: "${deployment.marketplace}" as \`0x\${string}\`,
    factory: "${deployment.factory}" as \`0x\${string}\`,
    usdc: "${deployment.usdc}" as \`0x\${string}\`,
    treasury: "${deployment.treasury}" as \`0x\${string}\`,
    deployer: "${deployment.deployer}" as \`0x\${string}\`,
    blockNumber: ${deployment.blockNumber},
  },
`
  }

  configContent += `} as const

export function getContractAddress(chainId: number, contract: keyof typeof deployedContracts[keyof typeof deployedContracts]): \`0x\${string}\` | undefined {
  const deployment = deployedContracts[chainId as keyof typeof deployedContracts]
  return deployment?.[contract] as \`0x\${string}\` | undefined
}
`

  fs.writeFileSync(configPath, configContent)
  console.log(`📄 Frontend config generated: ${configPath}`)
}

main()
  .then(() => process.exit(0))
  .catch((error) => {
    console.error(error)
    process.exit(1)
  })
