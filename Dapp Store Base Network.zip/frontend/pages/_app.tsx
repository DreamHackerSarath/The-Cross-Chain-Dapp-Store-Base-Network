import "@/styles/globals.css"
import "@rainbow-me/rainbowkit/styles.css"
import type { AppProps } from "next/app"
import { RainbowKitProvider } from "@rainbow-me/rainbowkit"
import { WagmiConfig } from "wagmi"
import { QueryClient, QueryClientProvider } from "@tanstack/react-query"
import { wagmiConfig, chains } from "@/lib/wagmi"
import { Header } from "@/components/layout/header"

const queryClient = new QueryClient()

export default function App({ Component, pageProps }: AppProps) {
  return (
    <WagmiConfig config={wagmiConfig}>
      <QueryClientProvider client={queryClient}>
        <RainbowKitProvider chains={chains}>
          <div className="min-h-screen bg-background">
            <Header />
            <main className="container mx-auto py-8">
              <Component {...pageProps} />
            </main>
          </div>
        </RainbowKitProvider>
      </QueryClientProvider>
    </WagmiConfig>
  )
}
