// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC1155/ERC1155.sol";
import "@openzeppelin/contracts/interfaces/IERC2981.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract Dapp1155 is ERC1155, IERC2981, Ownable {
    uint256 private _nextTokenId;
    uint96 public royaltyBps;
    address public royaltyRecipient;

    constructor(
        string memory baseURI,
        address owner,
        uint96 _royaltyBps
    ) ERC1155(baseURI) {
        royaltyBps = _royaltyBps;
        royaltyRecipient = owner;
        _transferOwnership(owner);
    }

    function mint(
        address to,
        uint256 amount,
        bytes memory data
    ) external onlyOwner returns (uint256) {
        uint256 tokenId = _nextTokenId++;
        _mint(to, tokenId, amount, data);
        return tokenId;
    }

    function mintBatch(
        address to,
        uint256[] memory amounts,
        bytes memory data
    ) external onlyOwner returns (uint256[] memory) {
        uint256[] memory tokenIds = new uint256[](amounts.length);
        for (uint256 i = 0; i < amounts.length; i++) {
            tokenIds[i] = _nextTokenId++;
        }
        _mintBatch(to, tokenIds, amounts, data);
        return tokenIds;
    }

    function setURI(string memory newURI) external onlyOwner {
        _setURI(newURI);
    }

    function setRoyalty(address recipient, uint96 bps) external onlyOwner {
        require(bps <= 10000, "Royalty too high");
        royaltyRecipient = recipient;
        royaltyBps = bps;
    }

    function royaltyInfo(uint256, uint256 salePrice)
        external
        view
        override
        returns (address, uint256)
    {
        uint256 royaltyAmount = (salePrice * royaltyBps) / 10000;
        return (royaltyRecipient, royaltyAmount);
    }

    function supportsInterface(bytes4 interfaceId)
        public
        view
        override(ERC1155, IERC165)
        returns (bool)
    {
        return
            interfaceId == type(IERC2981).interfaceId ||
            super.supportsInterface(interfaceId);
    }
}
