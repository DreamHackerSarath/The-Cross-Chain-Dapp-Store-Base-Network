import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import Link from "next/link"
import { Store, Zap, Shield, Globe } from "lucide-react"

export default function Home() {
  return (
    <div className="space-y-12">
      {/* Hero Section */}
      <section className="text-center space-y-6 py-12">
        <h1 className="text-4xl font-bold tracking-tight sm:text-6xl">
          The Cross-Chain
          <span className="text-primary"> Dapp Store</span>
        </h1>
        <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
          List and discover decentralized applications across all EVM chains. $1 listing fee, 10% commission, built for
          creators.
        </p>
        <div className="flex justify-center space-x-4">
          <Button asChild size="lg">
            <Link href="/market">Browse Market</Link>
          </Button>
          <Button asChild variant="outline" size="lg">
            <Link href="/list">List Your Dapp</Link>
          </Button>
        </div>
      </section>

      {/* Features */}
      <section className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="text-center">
            <Globe className="h-12 w-12 mx-auto text-primary" />
            <CardTitle>Multi-Chain</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground text-center">
              Deploy on Ethereum, Polygon, Base, Arbitrum, Optimism, and BSC
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="text-center">
            <Zap className="h-12 w-12 mx-auto text-primary" />
            <CardTitle>Low Fees</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground text-center">
              Just $1 USDC to list your dapp, 10% commission on sales
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="text-center">
            <Shield className="h-12 w-12 mx-auto text-primary" />
            <CardTitle>Secure Escrow</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground text-center">
              Optional escrow protection with dispute resolution
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="text-center">
            <Store className="h-12 w-12 mx-auto text-primary" />
            <CardTitle>NFT Powered</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-sm text-muted-foreground text-center">
              ERC-721 & ERC-1155 support with automatic royalties
            </p>
          </CardContent>
        </Card>
      </section>

      {/* Stats */}
      <section className="bg-muted/50 rounded-lg p-8">
        <div className="grid md:grid-cols-3 gap-8 text-center">
          <div>
            <h3 className="text-3xl font-bold">6</h3>
            <p className="text-muted-foreground">Supported Chains</p>
          </div>
          <div>
            <h3 className="text-3xl font-bold">$1</h3>
            <p className="text-muted-foreground">Listing Fee</p>
          </div>
          <div>
            <h3 className="text-3xl font-bold">10%</h3>
            <p className="text-muted-foreground">Commission</p>
          </div>
        </div>
      </section>
    </div>
  )
}
