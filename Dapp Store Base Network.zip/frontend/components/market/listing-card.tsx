"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { formatAddress, formatPrice } from "@/lib/utils"
import { CartManager } from "@/lib/cart"
import { Badge, ShoppingCart, Plus } from "lucide-react"
import { useState, useEffect } from "react"

interface Listing {
  id: number
  seller: string
  nft: string
  tokenId: number
  payToken: string
  price: string
  quantity: number
  listingType: number
  active: boolean
}

interface ListingCardProps {
  listing: Listing
  onBuy: (id: number) => void
  onReport: (id: number) => void
  isLoading?: boolean
  showUSDPrice?: boolean
  usdPrice?: number
}

export function ListingCard({ listing, onBuy, onReport, isLoading, showUSDPrice, usdPrice }: ListingCardProps) {
  const [isInCart, setIsInCart] = useState(false)

  useEffect(() => {
    const updateCartStatus = () => {
      setIsInCart(CartManager.isInCart(listing.id))
    }

    updateCartStatus()
    window.addEventListener("cartUpdated", updateCartStatus)

    return () => window.removeEventListener("cartUpdated", updateCartStatus)
  }, [listing.id])

  const isERC721 = listing.listingType === 0
  const payTokenSymbol = listing.payToken === "0x0000000000000000000000000000000000000000" ? "ETH" : "ERC20"

  const handleAddToCart = () => {
    CartManager.addToCart({
      listingId: listing.id,
      seller: listing.seller,
      nft: listing.nft,
      tokenId: listing.tokenId,
      payToken: listing.payToken,
      price: listing.price,
      quantity: listing.quantity,
      listingType: listing.listingType,
    })
  }

  const handleRemoveFromCart = () => {
    CartManager.removeFromCart(listing.id)
  }

  return (
    <Card className="w-full">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <CardTitle className="text-lg">
            {isERC721 ? "ERC-721" : "ERC-1155"} #{listing.tokenId}
          </CardTitle>
          <Badge className="text-xs px-2 py-1 bg-primary/10 text-primary">{listing.active ? "Active" : "Sold"}</Badge>
        </div>
        <p className="text-sm text-muted-foreground">by {formatAddress(listing.seller)}</p>
      </CardHeader>

      <CardContent className="space-y-4">
        <div className="space-y-2">
          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">NFT Contract:</span>
            <span className="font-mono">{formatAddress(listing.nft)}</span>
          </div>

          <div className="flex justify-between text-sm">
            <span className="text-muted-foreground">Price:</span>
            <div className="text-right">
              <span className="font-semibold">
                {formatPrice(listing.price)} {payTokenSymbol}
              </span>
              {showUSDPrice && usdPrice && (
                <div className="text-xs text-muted-foreground">
                  ≈ ${(Number.parseFloat(formatPrice(listing.price)) * usdPrice).toFixed(2)}
                </div>
              )}
            </div>
          </div>

          {!isERC721 && (
            <div className="flex justify-between text-sm">
              <span className="text-muted-foreground">Quantity:</span>
              <span>{listing.quantity}</span>
            </div>
          )}
        </div>

        {listing.active && (
          <div className="flex space-x-2">
            <Button onClick={() => onBuy(listing.id)} disabled={isLoading} className="flex-1">
              {isLoading ? "Processing..." : "Buy Now"}
            </Button>

            {isInCart ? (
              <Button variant="outline" onClick={handleRemoveFromCart} className="px-3 bg-transparent">
                <ShoppingCart className="h-4 w-4 fill-current" />
              </Button>
            ) : (
              <Button variant="outline" onClick={handleAddToCart} className="px-3 bg-transparent">
                <Plus className="h-4 w-4" />
              </Button>
            )}

            <Button variant="outline" size="sm" onClick={() => onReport(listing.id)}>
              Report
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )
}
