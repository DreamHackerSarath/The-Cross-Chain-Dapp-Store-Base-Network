"use client"

import { useState, useEffect } from "react"
import { useContractWrite } from "wagmi"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CartManager, type CartItem } from "@/lib/cart"
import { getTokenPriceUSD, formatUSD, calculateUSDValue } from "@/lib/pricing"
import { formatAddress, formatPrice } from "@/lib/utils"
import { MARKETPLACE_ABI, ERC20_ABI } from "@/lib/contracts"
import { ShoppingCart, X, CreditCard, Trash2 } from "lucide-react"

const CONTRACT_ADDRESS = process.env.NEXT_PUBLIC_CONTRACT_ADDRESS as `0x${string}`

interface CartSidebarProps {
  isOpen: boolean
  onClose: () => void
}

export function CartSidebar({ isOpen, onClose }: CartSidebarProps) {
  const [cart, setCart] = useState<CartItem[]>([])
  const [usdPrices, setUsdPrices] = useState<Record<string, number>>({})
  const [selectedPayToken, setSelectedPayToken] = useState<string>("")

  // Batch buy function
  const { write: buyMany, isLoading: isBuying } = useContractWrite({
    address: CONTRACT_ADDRESS,
    abi: MARKETPLACE_ABI,
    functionName: "buyMany",
  })

  // ERC20 approve function
  const { write: approveERC20, isLoading: isApproving } = useContractWrite({
    abi: ERC20_ABI,
    functionName: "approve",
  })

  useEffect(() => {
    const updateCart = () => setCart(CartManager.getCart())

    updateCart()
    window.addEventListener("cartUpdated", updateCart)

    return () => window.removeEventListener("cartUpdated", updateCart)
  }, [])

  useEffect(() => {
    const fetchPrices = async () => {
      const tokens = new Set<string>()
      cart.forEach((item) => {
        const symbol = item.payToken === "0x0000000000000000000000000000000000000000" ? "eth" : "usdc"
        tokens.add(symbol)
      })

      const prices: Record<string, number> = {}
      for (const token of tokens) {
        prices[token] = await getTokenPriceUSD(token)
      }
      setUsdPrices(prices)
    }

    if (cart.length > 0) {
      fetchPrices()
    }
  }, [cart])

  const removeFromCart = (listingId: number) => {
    CartManager.removeFromCart(listingId)
  }

  const clearCart = () => {
    CartManager.clearCart()
  }

  const groupedCart = CartManager.groupByPayToken()
  const payTokens = Object.keys(groupedCart)

  const handleCheckout = (payToken: string) => {
    const items = groupedCart[payToken]
    if (!items.length) return

    const listingIds = items.map((item) => BigInt(item.listingId))
    const totalValue = items.reduce((sum, item) => sum + BigInt(item.price), 0n)

    if (payToken === "0x0000000000000000000000000000000000000000") {
      // Native token payment
      buyMany({
        args: [listingIds],
        value: totalValue,
      })
    } else {
      // ERC20 payment (requires approval first)
      buyMany({
        args: [listingIds],
      })
    }
  }

  const handleApprove = (payToken: string) => {
    const items = groupedCart[payToken]
    const totalValue = items.reduce((sum, item) => sum + BigInt(item.price), 0n)

    approveERC20({
      address: payToken as `0x${string}`,
      args: [CONTRACT_ADDRESS, totalValue],
    })
  }

  const getTokenSymbol = (payToken: string) => {
    return payToken === "0x0000000000000000000000000000000000000000" ? "ETH" : "ERC20"
  }

  const getUSDValue = (item: CartItem) => {
    const symbol = item.payToken === "0x0000000000000000000000000000000000000000" ? "eth" : "usdc"
    const price = usdPrices[symbol] || 0
    return calculateUSDValue(item.price, price)
  }

  if (!isOpen) return null

  return (
    <div className="fixed inset-0 z-50 bg-black/50" onClick={onClose}>
      <div
        className="fixed right-0 top-0 h-full w-96 bg-background border-l shadow-lg overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold flex items-center gap-2">
              <ShoppingCart className="h-5 w-5" />
              Shopping Cart ({cart.length})
            </h2>
            <Button variant="ghost" size="icon" onClick={onClose}>
              <X className="h-4 w-4" />
            </Button>
          </div>

          {cart.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground">Your cart is empty</div>
          ) : (
            <div className="space-y-4">
              {/* Cart Items */}
              <div className="space-y-3">
                {cart.map((item) => (
                  <Card key={item.listingId} className="p-3">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="font-medium text-sm">
                          {item.listingType === 0 ? "ERC-721" : "ERC-1155"} #{item.tokenId}
                        </p>
                        <p className="text-xs text-muted-foreground">{formatAddress(item.seller)}</p>
                        <div className="flex items-center gap-2 mt-1">
                          <span className="text-sm font-medium">
                            {formatPrice(item.price)} {getTokenSymbol(item.payToken)}
                          </span>
                          {usdPrices && (
                            <span className="text-xs text-muted-foreground">≈ {formatUSD(getUSDValue(item))}</span>
                          )}
                        </div>
                      </div>
                      <Button
                        variant="ghost"
                        size="icon"
                        onClick={() => removeFromCart(item.listingId)}
                        className="h-8 w-8"
                      >
                        <X className="h-3 w-3" />
                      </Button>
                    </div>
                  </Card>
                ))}
              </div>

              {/* Checkout by Payment Token */}
              <div className="space-y-4">
                {payTokens.map((payToken) => {
                  const items = groupedCart[payToken]
                  const totalValue = items.reduce((sum, item) => sum + BigInt(item.price), 0n)
                  const symbol = getTokenSymbol(payToken)
                  const usdSymbol = payToken === "0x0000000000000000000000000000000000000000" ? "eth" : "usdc"
                  const totalUSD = calculateUSDValue(totalValue.toString(), usdPrices[usdSymbol] || 0)

                  return (
                    <Card key={payToken}>
                      <CardHeader className="pb-3">
                        <CardTitle className="text-sm">
                          Pay with {symbol} ({items.length} items)
                        </CardTitle>
                      </CardHeader>
                      <CardContent className="space-y-3">
                        <div className="flex justify-between text-sm">
                          <span>Total:</span>
                          <div className="text-right">
                            <div className="font-medium">
                              {formatPrice(totalValue.toString())} {symbol}
                            </div>
                            <div className="text-xs text-muted-foreground">≈ {formatUSD(totalUSD)}</div>
                          </div>
                        </div>

                        <div className="space-y-2">
                          {payToken !== "0x0000000000000000000000000000000000000000" && (
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleApprove(payToken)}
                              disabled={isApproving}
                              className="w-full"
                            >
                              {isApproving ? "Approving..." : `Approve ${symbol}`}
                            </Button>
                          )}

                          <Button onClick={() => handleCheckout(payToken)} disabled={isBuying} className="w-full">
                            <CreditCard className="h-4 w-4 mr-2" />
                            {isBuying ? "Processing..." : `Checkout ${items.length} items`}
                          </Button>
                        </div>
                      </CardContent>
                    </Card>
                  )
                })}
              </div>

              {/* Clear Cart */}
              <Button variant="outline" onClick={clearCart} className="w-full bg-transparent">
                <Trash2 className="h-4 w-4 mr-2" />
                Clear Cart
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
