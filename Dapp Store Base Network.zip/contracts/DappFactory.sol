// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "./Dapp721.sol";
import "./Dapp1155.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract DappFactory is Ownable {
    event CollectionCreated(
        address indexed creator,
        address indexed collection,
        string collectionType,
        string name,
        string symbol
    );

    function createDapp721(
        string memory name,
        string memory symbol,
        string memory baseURI,
        uint96 royaltyBps
    ) external returns (address) {
        Dapp721 collection = new Dapp721(
            name,
            symbol,
            baseURI,
            msg.sender,
            royaltyBps
        );

        emit CollectionCreated(
            msg.sender,
            address(collection),
            "ERC721",
            name,
            symbol
        );

        return address(collection);
    }

    function createDapp1155(
        string memory baseURI,
        uint96 royaltyBps
    ) external returns (address) {
        Dapp1155 collection = new Dapp1155(
            baseURI,
            msg.sender,
            royaltyBps
        );

        emit CollectionCreated(
            msg.sender,
            address(collection),
            "ERC1155",
            "",
            ""
        );

        return address(collection);
    }
}
