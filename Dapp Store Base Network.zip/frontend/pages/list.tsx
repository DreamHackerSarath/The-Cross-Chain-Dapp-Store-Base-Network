"use client"

import { useState } from "react"
import { useContractWrite, useContractRead, useAccount } from "wagmi"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { MARKETPLACE_ABI, ERC20_ABI, ERC721_ABI } from "@/lib/contracts"
import { parsePrice } from "@/lib/utils"

const CONTRACT_ADDRESS = process.env.NEXT_PUBLIC_CONTRACT_ADDRESS as `0x${string}`
const USDC_ADDRESS = process.env.NEXT_PUBLIC_USDC_ADDRESS as `0x${string}`

export default function List() {
  const { address } = useAccount()
  const [listingType, setListingType] = useState<"721" | "1155">("721")
  const [formData, setFormData] = useState({
    nftAddress: "",
    tokenId: "",
    payToken: "0x0000000000000000000000000000000000000000", // ETH by default
    price: "",
    quantity: "1",
  })

  // Get listing fee
  const { data: listingFee } = useContractRead({
    address: CONTRACT_ADDRESS,
    abi: MARKETPLACE_ABI,
    functionName: "getListingFee",
  })

  // Approve USDC for listing fee
  const { write: approveUSDC, isLoading: isApprovingUSDC } = useContractWrite({
    address: USDC_ADDRESS,
    abi: ERC20_ABI,
    functionName: "approve",
  })

  // Approve NFT
  const { write: approveNFT, isLoading: isApprovingNFT } = useContractWrite({
    address: formData.nftAddress as `0x${string}`,
    abi: ERC721_ABI,
    functionName: "setApprovalForAll",
  })

  // List ERC-721
  const { write: list721, isLoading: isListing721 } = useContractWrite({
    address: CONTRACT_ADDRESS,
    abi: MARKETPLACE_ABI,
    functionName: "list721",
  })

  // List ERC-1155
  const { write: list1155, isLoading: isListing1155 } = useContractWrite({
    address: CONTRACT_ADDRESS,
    abi: MARKETPLACE_ABI,
    functionName: "list1155",
  })

  const handleApproveUSDC = () => {
    if (!listingFee) return
    approveUSDC({
      args: [CONTRACT_ADDRESS, listingFee as bigint],
    })
  }

  const handleApproveNFT = () => {
    if (!formData.nftAddress) return
    approveNFT({
      args: [CONTRACT_ADDRESS, true],
    })
  }

  const handleList = () => {
    if (!formData.nftAddress || !formData.tokenId || !formData.price) return

    const price = parsePrice(formData.price)
    const tokenId = BigInt(formData.tokenId)
    const payToken = formData.payToken as `0x${string}`
    const nftAddress = formData.nftAddress as `0x${string}`

    if (listingType === "721") {
      list721({
        args: [nftAddress, tokenId, payToken, price],
      })
    } else {
      const quantity = BigInt(formData.quantity)
      list1155({
        args: [nftAddress, tokenId, payToken, price, quantity],
      })
    }
  }

  const isLoading = isApprovingUSDC || isApprovingNFT || isListing721 || isListing1155

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <h1 className="text-3xl font-bold">List Your Dapp</h1>

      {!address && (
        <Card>
          <CardContent className="pt-6">
            <p className="text-center text-muted-foreground">Connect your wallet to list your dapp</p>
          </CardContent>
        </Card>
      )}

      {address && (
        <div className="space-y-6">
          {/* Listing Type Selection */}
          <Card>
            <CardHeader>
              <CardTitle>NFT Type</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex space-x-4">
                <Button variant={listingType === "721" ? "default" : "outline"} onClick={() => setListingType("721")}>
                  ERC-721
                </Button>
                <Button variant={listingType === "1155" ? "default" : "outline"} onClick={() => setListingType("1155")}>
                  ERC-1155
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Listing Form */}
          <Card>
            <CardHeader>
              <CardTitle>Listing Details</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <label className="text-sm font-medium">NFT Contract Address</label>
                <Input
                  placeholder="0x..."
                  value={formData.nftAddress}
                  onChange={(e) => setFormData({ ...formData, nftAddress: e.target.value })}
                />
              </div>

              <div>
                <label className="text-sm font-medium">Token ID</label>
                <Input
                  type="number"
                  placeholder="1"
                  value={formData.tokenId}
                  onChange={(e) => setFormData({ ...formData, tokenId: e.target.value })}
                />
              </div>

              <div>
                <label className="text-sm font-medium">Payment Token</label>
                <select
                  className="w-full h-10 px-3 py-2 border border-input rounded-md bg-background"
                  value={formData.payToken}
                  onChange={(e) => setFormData({ ...formData, payToken: e.target.value })}
                >
                  <option value="0x0000000000000000000000000000000000000000">ETH</option>
                  <option value={USDC_ADDRESS}>USDC</option>
                </select>
              </div>

              <div>
                <label className="text-sm font-medium">Price</label>
                <Input
                  type="number"
                  step="0.0001"
                  placeholder="0.1"
                  value={formData.price}
                  onChange={(e) => setFormData({ ...formData, price: e.target.value })}
                />
              </div>

              {listingType === "1155" && (
                <div>
                  <label className="text-sm font-medium">Quantity</label>
                  <Input
                    type="number"
                    placeholder="1"
                    value={formData.quantity}
                    onChange={(e) => setFormData({ ...formData, quantity: e.target.value })}
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Approval Steps */}
          <Card>
            <CardHeader>
              <CardTitle>Approval Steps</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span>1. Approve $1 USDC for listing fee</span>
                <Button onClick={handleApproveUSDC} disabled={isLoading} size="sm">
                  {isApprovingUSDC ? "Approving..." : "Approve USDC"}
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <span>2. Approve NFT for marketplace</span>
                <Button onClick={handleApproveNFT} disabled={isLoading || !formData.nftAddress} size="sm">
                  {isApprovingNFT ? "Approving..." : "Approve NFT"}
                </Button>
              </div>

              <div className="flex items-center justify-between">
                <span>3. Create listing</span>
                <Button
                  onClick={handleList}
                  disabled={isLoading || !formData.nftAddress || !formData.tokenId || !formData.price}
                >
                  {isListing721 || isListing1155 ? "Listing..." : "List Item"}
                </Button>
              </div>
            </CardContent>
          </Card>

          {listingFee && (
            <Card>
              <CardContent className="pt-6">
                <p className="text-sm text-muted-foreground text-center">
                  Listing fee: {(Number(listingFee) / 1e6).toFixed(2)} USDC
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      )}
    </div>
  )
}
