// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/ERC721.sol";
import "@openzeppelin/contracts/token/ERC721/extensions/ERC721URIStorage.sol";
import "@openzeppelin/contracts/interfaces/IERC2981.sol";
import "@openzeppelin/contracts/access/Ownable.sol";

contract Dapp721 is ERC721, ERC721URIStorage, IERC2981, Ownable {
    uint256 private _nextTokenId;
    string private _baseTokenURI;
    uint96 public royaltyBps;
    address public royaltyRecipient;

    constructor(
        string memory name,
        string memory symbol,
        string memory baseURI,
        address owner,
        uint96 _royaltyBps
    ) ERC721(name, symbol) {
        _baseTokenURI = baseURI;
        royaltyBps = _royaltyBps;
        royaltyRecipient = owner;
        _transferOwnership(owner);
    }

    function mint(address to, string memory tokenURI) external onlyOwner returns (uint256) {
        uint256 tokenId = _nextTokenId++;
        _safeMint(to, tokenId);
        _setTokenURI(tokenId, tokenURI);
        return tokenId;
    }

    function setBaseURI(string memory baseURI) external onlyOwner {
        _baseTokenURI = baseURI;
    }

    function setRoyalty(address recipient, uint96 bps) external onlyOwner {
        require(bps <= 10000, "Royalty too high");
        royaltyRecipient = recipient;
        royaltyBps = bps;
    }

    function _baseURI() internal view override returns (string memory) {
        return _baseTokenURI;
    }

    function tokenURI(uint256 tokenId)
        public
        view
        override(ERC721, ERC721URIStorage)
        returns (string memory)
    {
        return super.tokenURI(tokenId);
    }

    function royaltyInfo(uint256, uint256 salePrice)
        external
        view
        override
        returns (address, uint256)
    {
        uint256 royaltyAmount = (salePrice * royaltyBps) / 10000;
        return (royaltyRecipient, royaltyAmount);
    }

    function supportsInterface(bytes4 interfaceId)
        public
        view
        override(ERC721, ERC721URIStorage, IERC165)
        returns (bool)
    {
        return
            interfaceId == type(IERC2981).interfaceId ||
            super.supportsInterface(interfaceId);
    }

    function _burn(uint256 tokenId) internal override(ERC721, ERC721URIStorage) {
        super._burn(tokenId);
    }
}
