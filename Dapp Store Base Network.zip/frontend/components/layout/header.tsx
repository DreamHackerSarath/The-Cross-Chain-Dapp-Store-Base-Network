import { ConnectButton } from "@rainbow-me/rainbowkit"
import Link from "next/link"
import { Store, Plus, BarChart3, Palette, Coins, Settings } from "lucide-react"
import { ChainSelector } from "@/components/chain-selector"

export function Header() {
  return (
    <header className="border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center justify-between">
        <div className="flex items-center space-x-6">
          <Link href="/" className="flex items-center space-x-2">
            <Store className="h-6 w-6" />
            <span className="font-bold text-xl">Dapp Store</span>
          </Link>

          <nav className="flex items-center space-x-4">
            <Link
              href="/market"
              className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              Market
            </Link>
            <Link
              href="/list"
              className="flex items-center space-x-1 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <Plus className="h-4 w-4" />
              <span>List</span>
            </Link>
            <Link
              href="/create"
              className="flex items-center space-x-1 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <Palette className="h-4 w-4" />
              <span>Create</span>
            </Link>
            <Link
              href="/mint"
              className="flex items-center space-x-1 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <Coins className="h-4 w-4" />
              <span>Mint</span>
            </Link>
            <Link
              href="/analytics"
              className="flex items-center space-x-1 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <BarChart3 className="h-4 w-4" />
              <span>Analytics</span>
            </Link>
            <Link
              href="/admin"
              className="flex items-center space-x-1 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
            >
              <Settings className="h-4 w-4" />
              <span>Admin</span>
            </Link>
          </nav>
        </div>

        <div className="flex items-center space-x-4">
          <ChainSelector />
          <ConnectButton />
        </div>
      </div>
    </header>
  )
}
