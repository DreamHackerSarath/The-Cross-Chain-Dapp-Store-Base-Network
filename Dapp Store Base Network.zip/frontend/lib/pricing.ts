interface TokenPrice {
  usd: number
  lastUpdated: number
}

const PRICE_CACHE_DURATION = 5 * 60 * 1000 // 5 minutes
const priceCache = new Map<string, TokenPrice>()

export async function getTokenPriceUSD(tokenSymbol: string): Promise<number> {
  const cacheKey = tokenSymbol.toLowerCase()
  const cached = priceCache.get(cacheKey)

  if (cached && Date.now() - cached.lastUpdated < PRICE_CACHE_DURATION) {
    return cached.usd
  }

  try {
    // Using CoinGecko API (free tier)
    const coinGeckoIds: Record<string, string> = {
      eth: "ethereum",
      matic: "matic-network",
      bnb: "binancecoin",
      usdc: "usd-coin",
      usdt: "tether",
    }

    const coinId = coinGeckoIds[cacheKey] || cacheKey
    const response = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${coinId}&vs_currencies=usd`)

    if (!response.ok) throw new Error("Price fetch failed")

    const data = await response.json()
    const price = data[coinId]?.usd || 0

    priceCache.set(cacheKey, {
      usd: price,
      lastUpdated: Date.now(),
    })

    return price
  } catch (error) {
    console.error(`Failed to fetch price for ${tokenSymbol}:`, error)
    return 0
  }
}

export function formatUSD(amount: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(amount)
}

export function calculateUSDValue(tokenAmount: string, tokenPrice: number, decimals = 18): number {
  const amount = Number.parseFloat(tokenAmount) / Math.pow(10, decimals)
  return amount * tokenPrice
}
