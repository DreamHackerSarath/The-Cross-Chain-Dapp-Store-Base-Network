"use client"

import { useState } from "react"
import { usePublicClient, useContractRead, useAccount } from "wagmi"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { MARKETPLACE_ABI } from "@/lib/contracts"
import { formatAddress, formatPrice } from "@/lib/utils"
import { BarChart3, TrendingUp, DollarSign, Package, Download, Users, Eye } from "lucide-react"

const CONTRACT_ADDRESS = process.env.NEXT_PUBLIC_CONTRACT_ADDRESS as `0x${string}`

interface AnalyticsData {
  totalListings: number
  totalSales: number
  totalVolume: bigint
  totalCommission: bigint
  uniqueSellers: number
  sellerStats: SellerStats[]
  recentActivity: ActivityEvent[]
}

interface SellerStats {
  seller: string
  listings: number
  sales: number
  volume: bigint
  commission: bigint
  avgPrice: bigint
}

interface ActivityEvent {
  type: "Listed" | "Bought" | "Cancelled"
  id: number
  seller: string
  buyer?: string
  price: bigint
  timestamp: number
  txHash: string
}

export default function Analytics() {
  const { address } = useAccount()
  const publicClient = usePublicClient()
  const [blockRange, setBlockRange] = useState({ from: "", to: "" })
  const [analytics, setAnalytics] = useState<AnalyticsData | null>(null)
  const [isLoading, setIsLoading] = useState(false)
  const [selectedSeller, setSelectedSeller] = useState<string>("")

  const { data: commissionBps } = useContractRead({
    address: CONTRACT_ADDRESS,
    abi: MARKETPLACE_ABI,
    functionName: "commissionBps",
  })

  const fetchAnalytics = async () => {
    if (!publicClient || !blockRange.from) return

    setIsLoading(true)
    try {
      const fromBlock = BigInt(blockRange.from)
      const toBlock = blockRange.to ? BigInt(blockRange.to) : "latest"

      const listedLogs = await publicClient.getLogs({
        address: CONTRACT_ADDRESS,
        event: {
          type: "event",
          name: "Listed",
          inputs: [
            { indexed: true, name: "id", type: "uint256" },
            { indexed: true, name: "seller", type: "address" },
            { indexed: true, name: "nft", type: "address" },
            { indexed: false, name: "tokenId", type: "uint256" },
            { indexed: false, name: "payToken", type: "address" },
            { indexed: false, name: "price", type: "uint256" },
            { indexed: false, name: "quantity", type: "uint256" },
            { indexed: false, name: "listingType", type: "uint8" },
          ],
        },
        fromBlock,
        toBlock,
      })

      const boughtLogs = await publicClient.getLogs({
        address: CONTRACT_ADDRESS,
        event: {
          type: "event",
          name: "Bought",
          inputs: [
            { indexed: true, name: "id", type: "uint256" },
            { indexed: true, name: "buyer", type: "address" },
            { indexed: false, name: "price", type: "uint256" },
          ],
        },
        fromBlock,
        toBlock,
      })

      const cancelledLogs = await publicClient.getLogs({
        address: CONTRACT_ADDRESS,
        event: {
          type: "event",
          name: "Cancelled",
          inputs: [{ indexed: true, name: "id", type: "uint256" }],
        },
        fromBlock,
        toBlock,
      })

      const sellerMap = new Map<string, SellerStats>()
      const recentActivity: ActivityEvent[] = []
      let totalVolume = 0n
      let totalCommission = 0n

      // Process listings
      for (const log of listedLogs) {
        const { id, seller, price } = log.args as any
        const block = await publicClient.getBlock({ blockHash: log.blockHash })

        if (!sellerMap.has(seller)) {
          sellerMap.set(seller, {
            seller,
            listings: 0,
            sales: 0,
            volume: 0n,
            commission: 0n,
            avgPrice: 0n,
          })
        }

        const stats = sellerMap.get(seller)!
        stats.listings++

        recentActivity.push({
          type: "Listed",
          id: Number(id),
          seller,
          price,
          timestamp: Number(block.timestamp),
          txHash: log.transactionHash,
        })
      }

      // Process sales
      for (const log of boughtLogs) {
        const { id, buyer, price } = log.args as any
        const block = await publicClient.getBlock({ blockHash: log.blockHash })

        // Find corresponding listing to get seller
        const listingLog = listedLogs.find((l) => (l.args as any).id === id)
        if (listingLog) {
          const seller = (listingLog.args as any).seller
          const stats = sellerMap.get(seller)
          if (stats) {
            stats.sales++
            stats.volume += price

            // Calculate commission (10% default)
            const commission = (price * BigInt(commissionBps || 1000)) / 10000n
            stats.commission += commission
            totalCommission += commission
          }
        }

        totalVolume += price

        recentActivity.push({
          type: "Bought",
          id: Number(id),
          seller: listingLog ? (listingLog.args as any).seller : "",
          buyer,
          price,
          timestamp: Number(block.timestamp),
          txHash: log.transactionHash,
        })
      }

      // Process cancellations
      for (const log of cancelledLogs) {
        const { id } = log.args as any
        const block = await publicClient.getBlock({ blockHash: log.blockHash })

        const listingLog = listedLogs.find((l) => (l.args as any).id === id)
        if (listingLog) {
          const seller = (listingLog.args as any).seller
          const price = (listingLog.args as any).price

          recentActivity.push({
            type: "Cancelled",
            id: Number(id),
            seller,
            price,
            timestamp: Number(block.timestamp),
            txHash: log.transactionHash,
          })
        }
      }

      // Calculate average prices
      sellerMap.forEach((stats) => {
        if (stats.sales > 0) {
          stats.avgPrice = stats.volume / BigInt(stats.sales)
        }
      })

      // Sort recent activity by timestamp
      recentActivity.sort((a, b) => b.timestamp - a.timestamp)

      const analyticsData: AnalyticsData = {
        totalListings: listedLogs.length,
        totalSales: boughtLogs.length,
        totalVolume,
        totalCommission,
        uniqueSellers: sellerMap.size,
        sellerStats: Array.from(sellerMap.values()).sort((a, b) => Number(b.volume - a.volume)),
        recentActivity: recentActivity.slice(0, 50), // Latest 50 events
      }

      setAnalytics(analyticsData)
    } catch (error) {
      console.error("Failed to fetch analytics:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const exportToCSV = () => {
    if (!analytics) return

    const csvData = [
      ["Seller", "Listings", "Sales", "Volume (ETH)", "Commission (ETH)", "Avg Price (ETH)"],
      ...analytics.sellerStats.map((stats) => [
        stats.seller,
        stats.listings.toString(),
        stats.sales.toString(),
        formatPrice(stats.volume.toString()),
        formatPrice(stats.commission.toString()),
        formatPrice(stats.avgPrice.toString()),
      ]),
    ]

    const csvContent = csvData.map((row) => row.join(",")).join("\n")
    const blob = new Blob([csvContent], { type: "text/csv" })
    const url = URL.createObjectURL(blob)

    const a = document.createElement("a")
    a.href = url
    a.download = `marketplace-analytics-${Date.now()}.csv`
    a.click()

    URL.revokeObjectURL(url)
  }

  const filteredSellerStats = selectedSeller
    ? analytics?.sellerStats.filter((s) => s.seller.toLowerCase().includes(selectedSeller.toLowerCase()))
    : analytics?.sellerStats

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-3xl font-bold">Analytics Dashboard</h1>
        {analytics && (
          <Button onClick={exportToCSV} variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
        )}
      </div>

      {/* Block Range Input */}
      <Card>
        <CardHeader>
          <CardTitle>Query Range</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex space-x-4 items-end">
            <div className="flex-1">
              <label className="text-sm font-medium">From Block</label>
              <Input
                type="number"
                placeholder="18000000"
                value={blockRange.from}
                onChange={(e) => setBlockRange({ ...blockRange, from: e.target.value })}
              />
            </div>
            <div className="flex-1">
              <label className="text-sm font-medium">To Block</label>
              <Input
                type="number"
                placeholder="latest"
                value={blockRange.to}
                onChange={(e) => setBlockRange({ ...blockRange, to: e.target.value })}
              />
            </div>
            <Button onClick={fetchAnalytics} disabled={isLoading || !blockRange.from}>
              {isLoading ? "Analyzing..." : "Analyze"}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Stats Overview */}
      <div className="grid md:grid-cols-2 lg:grid-cols-5 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Listings</CardTitle>
            <Package className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics?.totalListings || 0}</div>
            <p className="text-xs text-muted-foreground">Items listed for sale</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Sales</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics?.totalSales || 0}</div>
            <p className="text-xs text-muted-foreground">Successful transactions</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Volume</CardTitle>
            <DollarSign className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {analytics ? formatPrice(analytics.totalVolume.toString()) : "0"} ETH
            </div>
            <p className="text-xs text-muted-foreground">Total trading volume</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Commission</CardTitle>
            <BarChart3 className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {analytics ? formatPrice(analytics.totalCommission.toString()) : "0"} ETH
            </div>
            <p className="text-xs text-muted-foreground">
              {commissionBps ? Number(commissionBps) / 100 : 10}% of total volume
            </p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Sellers</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{analytics?.uniqueSellers || 0}</div>
            <p className="text-xs text-muted-foreground">Unique sellers</p>
          </CardContent>
        </Card>
      </div>

      {/* Seller Statistics */}
      {analytics && (
        <Card>
          <CardHeader>
            <div className="flex items-center justify-between">
              <CardTitle>Seller Statistics</CardTitle>
              <div className="flex items-center space-x-2">
                <Eye className="h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Filter by seller address..."
                  value={selectedSeller}
                  onChange={(e) => setSelectedSeller(e.target.value)}
                  className="w-64"
                />
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b">
                    <th className="text-left p-2">Seller</th>
                    <th className="text-right p-2">Listings</th>
                    <th className="text-right p-2">Sales</th>
                    <th className="text-right p-2">Volume</th>
                    <th className="text-right p-2">Commission</th>
                    <th className="text-right p-2">Avg Price</th>
                  </tr>
                </thead>
                <tbody>
                  {filteredSellerStats?.slice(0, 20).map((stats, index) => (
                    <tr key={stats.seller} className="border-b hover:bg-muted/50">
                      <td className="p-2 font-mono text-xs">{formatAddress(stats.seller)}</td>
                      <td className="p-2 text-right">{stats.listings}</td>
                      <td className="p-2 text-right">{stats.sales}</td>
                      <td className="p-2 text-right">{formatPrice(stats.volume.toString())} ETH</td>
                      <td className="p-2 text-right">{formatPrice(stats.commission.toString())} ETH</td>
                      <td className="p-2 text-right">{formatPrice(stats.avgPrice.toString())} ETH</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Recent Activity */}
      {analytics && (
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {analytics.recentActivity.slice(0, 10).map((event, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-muted/50 rounded">
                  <div className="flex items-center space-x-3">
                    <div
                      className={`w-2 h-2 rounded-full ${
                        event.type === "Listed"
                          ? "bg-blue-500"
                          : event.type === "Bought"
                            ? "bg-green-500"
                            : "bg-red-500"
                      }`}
                    />
                    <div>
                      <p className="text-sm font-medium">
                        {event.type} #{event.id}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {event.type === "Bought" && event.buyer && <>Buyer: {formatAddress(event.buyer)} • </>}
                        Seller: {formatAddress(event.seller)}
                      </p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm font-medium">{formatPrice(event.price.toString())} ETH</p>
                    <p className="text-xs text-muted-foreground">
                      {new Date(event.timestamp * 1000).toLocaleDateString()}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* No data state */}
      {!analytics && !isLoading && (
        <Card>
          <CardHeader>
            <CardTitle>Analytics Data</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64 flex items-center justify-center text-muted-foreground">
              {address
                ? "Specify a block range and click 'Analyze' to view marketplace analytics"
                : "Connect your wallet and specify block range to view analytics"}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
