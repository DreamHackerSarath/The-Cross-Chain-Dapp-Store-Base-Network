# EVM Dapp Store

A cross-chain marketplace for dApps with $1 USDC listing fee and 10% commission system.

## Features

- **Multi-chain support**: Deploy on Ethereum, Polygon, Base, Arbitrum, Optimism, BSC
- **ERC-721 & ERC-1155 support**: List both NFT types with escrow protection
- **EIP-2981 royalties**: Automatic royalty payments to creators
- **Batch purchasing**: Buy multiple items in one transaction
- **Escrow system**: Optional buyer protection with dispute resolution
- **Moderation tools**: Report listings, admin freeze/unfreeze
- **Auto USDC detection**: Automatically calculates $1 fee based on token decimals

## Quick Start

### 1. Deploy Contracts

\`\`\`bash
cd contracts
cp .env.example .env
# Edit .env with your PRIVATE_KEY, USDC_ADDRESS, TREASURY_ADDRESS
npm install
npx hardhat compile
npx hardhat run scripts/deploy.js --network base
\`\`\`

### 2. Multi-chain Deployment

\`\`\`bash
# Deploy to specific chains
npx hardhat run scripts/deploy-many.js --network ethereum polygon base

# Deploy to all supported chains
npx hardhat run scripts/deploy-many.js
\`\`\`

### 3. Setup Frontend Environment

\`\`\`bash
# Auto-generate frontend .env.local
node scripts/write-frontend-env.js CONTRACT=0x... USDC=0x... FACTORY=0x...
\`\`\`

## Contract Addresses

### USDC Addresses by Chain
- Ethereum: `0xA0b86a33E6441c8C06DD2b7c94b7E6E42342f8e1`
- Polygon: `0x2791Bca1f2de4661ED88A30C99A7a9449Aa84174`
- Base: `0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913`
- Arbitrum: `0xaf88d065e77c8cC2239327C5EDb3A432268e5831`
- Optimism: `0x0b2C639c533813f4Aa9D7837CAf62653d097Ff85`
- BSC: `0x8AC76a51cc950d9822D68b83fE1Ad97B32Cd580d`

## Architecture

### Smart Contracts

- **AdvancedDappMarket.sol**: Main marketplace with escrow, royalties, batch buying
- **DappFactory.sol**: Factory for creating ERC-721/1155 collections
- **Dapp721.sol**: ERC-721 with royalties and owner-only minting
- **Dapp1155.sol**: ERC-1155 with royalties and owner-only minting

### Key Functions

#### Listing
- `list721(nft, tokenId, payToken, price)`: List ERC-721
- `list1155(nft, tokenId, payToken, price, quantity)`: List ERC-1155

#### Buying
- `buyItem(id)`: Direct purchase
- `buyEscrow(id)`: Purchase with escrow protection
- `buyMany(ids[])`: Batch purchase (same pay token)

#### Escrow Management
- `releaseEscrow(id)`: Admin releases funds to seller
- `refundEscrow(id)`: Admin refunds buyer
- `expireEscrow(id)`: Auto-release after escrow window

#### Moderation
- `reportListing(id, reason)`: Report problematic listing
- `adminFreeze(id, freeze)`: Admin freeze/unfreeze listing

## Security Features

- **ReentrancyGuard**: Prevents reentrancy attacks
- **Escrow system**: Optional buyer protection
- **EIP-2981 royalties**: Automatic creator payments
- **Pay token allowlist**: Optional restriction on accepted tokens
- **Admin controls**: Freeze listings, manage escrows

## Testing

\`\`\`bash
npx hardhat test
\`\`\`

## License

MIT
