// SPDX-License-Identifier: MIT
pragma solidity ^0.8.20;

import "@openzeppelin/contracts/token/ERC721/IERC721.sol";
import "@openzeppelin/contracts/token/ERC1155/IERC1155.sol";
import "@openzeppelin/contracts/token/ERC20/IERC20.sol";
import "@openzeppelin/contracts/token/ERC20/extensions/IERC20Metadata.sol";
import "@openzeppelin/contracts/interfaces/IERC2981.sol";
import "@openzeppelin/contracts/security/ReentrancyGuard.sol";
import "@openzeppelin/contracts/access/Ownable.sol";
import "@openzeppelin/contracts/utils/introspection/ERC165Checker.sol";

contract AdvancedDappMarket is ReentrancyGuard, Ownable {
    using ERC165Checker for address;

    IERC20Metadata public usdc;
    address public treasury;
    uint256 public commissionBps = 1000; // 10% = 1000 bps
    uint256 public escrowWindow = 3 days;
    bool public requireAllowedPayTokens = false;

    enum ListingType { ERC721, ERC1155 }

    struct Listing {
        address seller;
        address nft;
        uint256 tokenId;
        address payToken; // address(0) for native token
        uint256 price;
        uint256 quantity; // for ERC1155
        ListingType listingType;
        bool active;
    }

    struct Escrow {
        address buyer;
        address payToken;
        uint256 amount;
        uint256 deadline;
        bool exists;
    }

    uint256 public nextListingId;
    mapping(uint256 => Listing) public listings;
    mapping(uint256 => Escrow) public escrows;
    mapping(uint256 => uint256) public reportCount;
    mapping(uint256 => bool) public frozen;
    mapping(address => bool) public allowedPayTokens;

    event Listed(
        uint256 indexed id,
        address indexed seller,
        address indexed nft,
        uint256 tokenId,
        address payToken,
        uint256 price,
        uint256 quantity,
        ListingType listingType
    );
    event Bought(uint256 indexed id, address indexed buyer, uint256 price);
    event Cancelled(uint256 indexed id);
    event Reported(uint256 indexed id, address indexed reporter, string reason);
    event Frozen(uint256 indexed id, bool frozen);
    event EscrowCreated(uint256 indexed id, address indexed buyer, uint256 amount);
    event EscrowReleased(uint256 indexed id);
    event EscrowRefunded(uint256 indexed id);

    constructor(IERC20Metadata _usdc, address _treasury) {
        usdc = _usdc;
        treasury = _treasury;
        allowedPayTokens[address(0)] = true; // native token allowed by default
        allowedPayTokens[address(_usdc)] = true; // USDC allowed by default
    }

    modifier notFrozen(uint256 id) {
        require(!frozen[id], "Listing is frozen");
        _;
    }

    function setTreasury(address _treasury) external onlyOwner {
        treasury = _treasury;
    }

    function setCommissionBps(uint256 _bps) external onlyOwner {
        require(_bps <= 10000, "Commission too high");
        commissionBps = _bps;
    }

    function setUSDC(IERC20Metadata _usdc) external onlyOwner {
        usdc = _usdc;
        allowedPayTokens[address(_usdc)] = true;
    }

    function setEscrowWindow(uint256 _window) external onlyOwner {
        escrowWindow = _window;
    }

    function setPayTokenAllowed(address token, bool allowed) external onlyOwner {
        allowedPayTokens[token] = allowed;
    }

    function setRequireAllowedPayTokens(bool required) external onlyOwner {
        requireAllowedPayTokens = required;
    }

    function adminFreeze(uint256 id, bool freeze) external onlyOwner {
        frozen[id] = freeze;
        emit Frozen(id, freeze);
    }

    function getListingFee() public view returns (uint256) {
        return 1 * (10 ** usdc.decimals());
    }

    function list721(
        address nft,
        uint256 tokenId,
        address payToken,
        uint256 price
    ) external nonReentrant {
        require(price > 0, "Price must be > 0");
        if (requireAllowedPayTokens) {
            require(allowedPayTokens[payToken], "Pay token not allowed");
        }

        // Collect listing fee
        require(
            usdc.transferFrom(msg.sender, address(this), getListingFee()),
            "USDC transfer failed"
        );

        // Transfer NFT to escrow
        IERC721(nft).transferFrom(msg.sender, address(this), tokenId);

        listings[nextListingId] = Listing({
            seller: msg.sender,
            nft: nft,
            tokenId: tokenId,
            payToken: payToken,
            price: price,
            quantity: 1,
            listingType: ListingType.ERC721,
            active: true
        });

        emit Listed(
            nextListingId,
            msg.sender,
            nft,
            tokenId,
            payToken,
            price,
            1,
            ListingType.ERC721
        );

        nextListingId++;
    }

    function list1155(
        address nft,
        uint256 tokenId,
        address payToken,
        uint256 price,
        uint256 quantity
    ) external nonReentrant {
        require(price > 0, "Price must be > 0");
        require(quantity > 0, "Quantity must be > 0");
        if (requireAllowedPayTokens) {
            require(allowedPayTokens[payToken], "Pay token not allowed");
        }

        // Collect listing fee
        require(
            usdc.transferFrom(msg.sender, address(this), getListingFee()),
            "USDC transfer failed"
        );

        // Transfer NFT to escrow
        IERC1155(nft).safeTransferFrom(msg.sender, address(this), tokenId, quantity, "");

        listings[nextListingId] = Listing({
            seller: msg.sender,
            nft: nft,
            tokenId: tokenId,
            payToken: payToken,
            price: price,
            quantity: quantity,
            listingType: ListingType.ERC1155,
            active: true
        });

        emit Listed(
            nextListingId,
            msg.sender,
            nft,
            tokenId,
            payToken,
            price,
            quantity,
            ListingType.ERC1155
        );

        nextListingId++;
    }

    function buyItem(uint256 id) external payable nonReentrant notFrozen(id) {
        _executeBuy(id, msg.sender);
    }

    function buyEscrow(uint256 id) external payable nonReentrant notFrozen(id) {
        Listing storage listing = listings[id];
        require(listing.active, "Listing not active");
        require(!escrows[id].exists, "Escrow already exists");

        uint256 totalPrice = listing.price;

        // Handle payment
        if (listing.payToken == address(0)) {
            require(msg.value == totalPrice, "Incorrect payment amount");
        } else {
            require(msg.value == 0, "Should not send ETH for ERC20 payment");
            IERC20(listing.payToken).transferFrom(msg.sender, address(this), totalPrice);
        }

        // Create escrow
        escrows[id] = Escrow({
            buyer: msg.sender,
            payToken: listing.payToken,
            amount: totalPrice,
            deadline: block.timestamp + escrowWindow,
            exists: true
        });

        listing.active = false; // Reserve the listing

        emit EscrowCreated(id, msg.sender, totalPrice);
    }

    function releaseEscrow(uint256 id) external onlyOwner {
        Escrow storage escrow = escrows[id];
        require(escrow.exists, "Escrow does not exist");

        Listing storage listing = listings[id];
        
        _processPayment(listing, escrow.amount);
        _transferNFT(listing, escrow.buyer);

        delete escrows[id];
        emit EscrowReleased(id);
        emit Bought(id, escrow.buyer, escrow.amount);
    }

    function refundEscrow(uint256 id) external onlyOwner {
        Escrow storage escrow = escrows[id];
        require(escrow.exists, "Escrow does not exist");

        // Refund buyer
        if (escrow.payToken == address(0)) {
            (bool success, ) = escrow.buyer.call{value: escrow.amount}("");
            require(success, "Refund failed");
        } else {
            IERC20(escrow.payToken).transfer(escrow.buyer, escrow.amount);
        }

        // Reactivate listing
        listings[id].active = true;

        delete escrows[id];
        emit EscrowRefunded(id);
    }

    function expireEscrow(uint256 id) external {
        Escrow storage escrow = escrows[id];
        require(escrow.exists, "Escrow does not exist");
        require(block.timestamp > escrow.deadline, "Escrow not expired");

        // Auto-release to seller
        Listing storage listing = listings[id];
        
        _processPayment(listing, escrow.amount);
        _transferNFT(listing, escrow.buyer);

        delete escrows[id];
        emit EscrowReleased(id);
        emit Bought(id, escrow.buyer, escrow.amount);
    }

    function buyMany(uint256[] calldata ids) external payable nonReentrant {
        require(ids.length > 0, "No items to buy");
        
        address payToken = listings[ids[0]].payToken;
        uint256 totalPrice = 0;

        // Validate all items use same pay token and calculate total
        for (uint256 i = 0; i < ids.length; i++) {
            require(!frozen[ids[i]], "Item is frozen");
            require(listings[ids[i]].active, "Item not active");
            require(listings[ids[i]].payToken == payToken, "Mixed pay tokens not allowed");
            totalPrice += listings[ids[i]].price;
        }

        // Handle payment
        if (payToken == address(0)) {
            require(msg.value == totalPrice, "Incorrect payment amount");
        } else {
            require(msg.value == 0, "Should not send ETH for ERC20 payment");
            IERC20(payToken).transferFrom(msg.sender, address(this), totalPrice);
        }

        // Execute all purchases
        for (uint256 i = 0; i < ids.length; i++) {
            _executeBuy(ids[i], msg.sender);
        }
    }

    function _executeBuy(uint256 id, address buyer) internal {
        Listing storage listing = listings[id];
        require(listing.active, "Listing not active");

        _processPayment(listing, listing.price);
        _transferNFT(listing, buyer);

        listing.active = false;
        emit Bought(id, buyer, listing.price);
    }

    function _processPayment(Listing storage listing, uint256 amount) internal {
        uint256 commission = (amount * commissionBps) / 10000;
        uint256 royalty = 0;

        // Check for EIP-2981 royalties
        if (listing.nft.supportsInterface(type(IERC2981).interfaceId)) {
            (address royaltyRecipient, uint256 royaltyAmount) = IERC2981(listing.nft)
                .royaltyInfo(listing.tokenId, amount);
            
            if (royaltyRecipient != address(0) && royaltyAmount > 0) {
                royalty = royaltyAmount;
                if (listing.payToken == address(0)) {
                    (bool success, ) = royaltyRecipient.call{value: royalty}("");
                    require(success, "Royalty payment failed");
                } else {
                    IERC20(listing.payToken).transfer(royaltyRecipient, royalty);
                }
            }
        }

        uint256 sellerAmount = amount - commission - royalty;

        // Pay seller
        if (listing.payToken == address(0)) {
            (bool success, ) = listing.seller.call{value: sellerAmount}("");
            require(success, "Seller payment failed");
            (bool success2, ) = treasury.call{value: commission}("");
            require(success2, "Commission payment failed");
        } else {
            IERC20(listing.payToken).transfer(listing.seller, sellerAmount);
            IERC20(listing.payToken).transfer(treasury, commission);
        }
    }

    function _transferNFT(Listing storage listing, address to) internal {
        if (listing.listingType == ListingType.ERC721) {
            IERC721(listing.nft).transferFrom(address(this), to, listing.tokenId);
        } else {
            IERC1155(listing.nft).safeTransferFrom(
                address(this),
                to,
                listing.tokenId,
                listing.quantity,
                ""
            );
        }
    }

    function cancelListing(uint256 id) external nonReentrant {
        Listing storage listing = listings[id];
        require(listing.active, "Listing not active");
        require(
            msg.sender == listing.seller || msg.sender == owner(),
            "Not authorized"
        );

        _transferNFT(listing, listing.seller);
        listing.active = false;

        emit Cancelled(id);
    }

    function reportListing(uint256 id, string calldata reason) external {
        require(listings[id].seller != address(0), "Listing does not exist");
        reportCount[id]++;
        emit Reported(id, msg.sender, reason);
    }

    function withdrawUSDC() external onlyOwner {
        uint256 balance = usdc.balanceOf(address(this));
        require(balance > 0, "No USDC to withdraw");
        usdc.transfer(owner(), balance);
    }

    function onERC1155Received(
        address,
        address,
        uint256,
        uint256,
        bytes memory
    ) public pure returns (bytes4) {
        return this.onERC1155Received.selector;
    }

    function onERC1155BatchReceived(
        address,
        address,
        uint256[] memory,
        uint256[] memory,
        bytes memory
    ) public pure returns (bytes4) {
        return this.onERC1155BatchReceived.selector;
    }
}
